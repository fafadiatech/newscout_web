--
-- PostgreSQL database dump
--

-- Dumped from database version 11.6
-- Dumped by pg_dump version 11.6

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: dblink; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS dblink WITH SCHEMA public;


--
-- Name: EXTENSION dblink; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION dblink IS 'connect to other PostgreSQL databases from within a database';


SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: advertising_adgroup; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.advertising_adgroup (
    id integer NOT NULL,
    created_at timestamp with time zone NOT NULL,
    modified_at timestamp with time zone NOT NULL,
    is_active boolean NOT NULL,
    campaign_id integer NOT NULL
);


ALTER TABLE public.advertising_adgroup OWNER TO postgres;

--
-- Name: advertising_adgroup_category; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.advertising_adgroup_category (
    id integer NOT NULL,
    adgroup_id integer NOT NULL,
    category_id integer NOT NULL
);


ALTER TABLE public.advertising_adgroup_category OWNER TO postgres;

--
-- Name: advertising_adgroup_category_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.advertising_adgroup_category_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.advertising_adgroup_category_id_seq OWNER TO postgres;

--
-- Name: advertising_adgroup_category_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.advertising_adgroup_category_id_seq OWNED BY public.advertising_adgroup_category.id;


--
-- Name: advertising_adgroup_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.advertising_adgroup_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.advertising_adgroup_id_seq OWNER TO postgres;

--
-- Name: advertising_adgroup_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.advertising_adgroup_id_seq OWNED BY public.advertising_adgroup.id;


--
-- Name: advertising_adtype; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.advertising_adtype (
    id integer NOT NULL,
    created_at timestamp with time zone NOT NULL,
    modified_at timestamp with time zone NOT NULL,
    type character varying(100) NOT NULL
);


ALTER TABLE public.advertising_adtype OWNER TO postgres;

--
-- Name: advertising_adtype_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.advertising_adtype_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.advertising_adtype_id_seq OWNER TO postgres;

--
-- Name: advertising_adtype_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.advertising_adtype_id_seq OWNED BY public.advertising_adtype.id;


--
-- Name: advertising_advertisement; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.advertising_advertisement (
    id integer NOT NULL,
    created_at timestamp with time zone NOT NULL,
    modified_at timestamp with time zone NOT NULL,
    ad_text character varying(160) NOT NULL,
    ad_url character varying(200) NOT NULL,
    media character varying(100),
    is_active boolean NOT NULL,
    impsn_limit integer NOT NULL,
    delivered integer NOT NULL,
    click_count integer NOT NULL,
    ad_type_id integer NOT NULL,
    adgroup_id integer NOT NULL
);


ALTER TABLE public.advertising_advertisement OWNER TO postgres;

--
-- Name: advertising_advertisement_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.advertising_advertisement_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.advertising_advertisement_id_seq OWNER TO postgres;

--
-- Name: advertising_advertisement_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.advertising_advertisement_id_seq OWNED BY public.advertising_advertisement.id;


--
-- Name: advertising_campaign; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.advertising_campaign (
    id integer NOT NULL,
    created_at timestamp with time zone NOT NULL,
    modified_at timestamp with time zone NOT NULL,
    name character varying(160) NOT NULL,
    is_active boolean NOT NULL,
    daily_budget numeric(8,2),
    max_bid numeric(8,2),
    start_date timestamp with time zone NOT NULL,
    end_date timestamp with time zone NOT NULL,
    domain_id integer NOT NULL
);


ALTER TABLE public.advertising_campaign OWNER TO postgres;

--
-- Name: advertising_campaign_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.advertising_campaign_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.advertising_campaign_id_seq OWNER TO postgres;

--
-- Name: advertising_campaign_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.advertising_campaign_id_seq OWNED BY public.advertising_campaign.id;


--
-- Name: auth_group; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.auth_group (
    id integer NOT NULL,
    name character varying(150) NOT NULL
);


ALTER TABLE public.auth_group OWNER TO postgres;

--
-- Name: auth_group_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.auth_group_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_group_id_seq OWNER TO postgres;

--
-- Name: auth_group_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.auth_group_id_seq OWNED BY public.auth_group.id;


--
-- Name: auth_group_permissions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.auth_group_permissions (
    id integer NOT NULL,
    group_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.auth_group_permissions OWNER TO postgres;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.auth_group_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_group_permissions_id_seq OWNER TO postgres;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.auth_group_permissions_id_seq OWNED BY public.auth_group_permissions.id;


--
-- Name: auth_permission; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.auth_permission (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    content_type_id integer NOT NULL,
    codename character varying(100) NOT NULL
);


ALTER TABLE public.auth_permission OWNER TO postgres;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.auth_permission_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_permission_id_seq OWNER TO postgres;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.auth_permission_id_seq OWNED BY public.auth_permission.id;


--
-- Name: authtoken_token; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.authtoken_token (
    key character varying(40) NOT NULL,
    created timestamp with time zone NOT NULL,
    user_id integer NOT NULL
);


ALTER TABLE public.authtoken_token OWNER TO postgres;

--
-- Name: captcha_captchastore; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.captcha_captchastore (
    id integer NOT NULL,
    challenge character varying(32) NOT NULL,
    response character varying(32) NOT NULL,
    hashkey character varying(40) NOT NULL,
    expiration timestamp with time zone NOT NULL
);


ALTER TABLE public.captcha_captchastore OWNER TO postgres;

--
-- Name: captcha_captchastore_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.captcha_captchastore_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.captcha_captchastore_id_seq OWNER TO postgres;

--
-- Name: captcha_captchastore_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.captcha_captchastore_id_seq OWNED BY public.captcha_captchastore.id;


--
-- Name: core_article; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.core_article (
    id integer NOT NULL,
    created_at timestamp with time zone NOT NULL,
    modified_at timestamp with time zone NOT NULL,
    title character varying(600) NOT NULL,
    source_url text NOT NULL,
    cover_image text NOT NULL,
    blurb text,
    full_text text NOT NULL,
    published_on timestamp with time zone NOT NULL,
    active boolean NOT NULL,
    hot boolean NOT NULL,
    popular boolean NOT NULL,
    avg_rating double precision,
    view_count double precision,
    rating_count double precision,
    manually_edit boolean NOT NULL,
    edited_on timestamp with time zone NOT NULL,
    indexed_on timestamp with time zone NOT NULL,
    spam boolean NOT NULL,
    category_id integer,
    domain_id integer,
    edited_by_id integer,
    source_id integer NOT NULL,
    article_format character varying(100),
    author_id integer,
    slug character varying(250)
);


ALTER TABLE public.core_article OWNER TO postgres;

--
-- Name: core_article_hash_tags; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.core_article_hash_tags (
    id integer NOT NULL,
    article_id integer NOT NULL,
    hashtag_id integer NOT NULL
);


ALTER TABLE public.core_article_hash_tags OWNER TO postgres;

--
-- Name: core_article_hash_tags_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.core_article_hash_tags_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.core_article_hash_tags_id_seq OWNER TO postgres;

--
-- Name: core_article_hash_tags_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.core_article_hash_tags_id_seq OWNED BY public.core_article_hash_tags.id;


--
-- Name: core_article_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.core_article_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.core_article_id_seq OWNER TO postgres;

--
-- Name: core_article_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.core_article_id_seq OWNED BY public.core_article.id;


--
-- Name: core_articlelike; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.core_articlelike (
    id integer NOT NULL,
    created_at timestamp with time zone NOT NULL,
    modified_at timestamp with time zone NOT NULL,
    is_like smallint NOT NULL,
    article_id integer NOT NULL,
    user_id integer NOT NULL,
    CONSTRAINT core_artilclelike_is_like_check CHECK ((is_like >= 0))
);


ALTER TABLE public.core_articlelike OWNER TO postgres;

--
-- Name: core_articlemedia; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.core_articlemedia (
    id integer NOT NULL,
    created_at timestamp with time zone NOT NULL,
    modified_at timestamp with time zone NOT NULL,
    category character varying(255) NOT NULL,
    url text,
    video_url text,
    article_id integer NOT NULL
);


ALTER TABLE public.core_articlemedia OWNER TO postgres;

--
-- Name: core_articlemedia_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.core_articlemedia_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.core_articlemedia_id_seq OWNER TO postgres;

--
-- Name: core_articlemedia_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.core_articlemedia_id_seq OWNED BY public.core_articlemedia.id;


--
-- Name: core_articlerating; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.core_articlerating (
    id integer NOT NULL,
    created_at timestamp with time zone NOT NULL,
    modified_at timestamp with time zone NOT NULL,
    rating double precision NOT NULL,
    article_id integer NOT NULL
);


ALTER TABLE public.core_articlerating OWNER TO postgres;

--
-- Name: core_articlerating_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.core_articlerating_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.core_articlerating_id_seq OWNER TO postgres;

--
-- Name: core_articlerating_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.core_articlerating_id_seq OWNED BY public.core_articlerating.id;


--
-- Name: core_artilclelike_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.core_artilclelike_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.core_artilclelike_id_seq OWNER TO postgres;

--
-- Name: core_artilclelike_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.core_artilclelike_id_seq OWNED BY public.core_articlelike.id;


--
-- Name: core_baseuserprofile; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.core_baseuserprofile (
    id integer NOT NULL,
    password character varying(128) NOT NULL,
    last_login timestamp with time zone,
    is_superuser boolean NOT NULL,
    username character varying(150) NOT NULL,
    first_name character varying(30) NOT NULL,
    last_name character varying(150) NOT NULL,
    email character varying(254) NOT NULL,
    is_staff boolean NOT NULL,
    is_active boolean NOT NULL,
    date_joined timestamp with time zone NOT NULL,
    domain_id integer,
    is_editor boolean NOT NULL
);


ALTER TABLE public.core_baseuserprofile OWNER TO postgres;

--
-- Name: core_baseuserprofile_groups; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.core_baseuserprofile_groups (
    id integer NOT NULL,
    baseuserprofile_id integer NOT NULL,
    group_id integer NOT NULL
);


ALTER TABLE public.core_baseuserprofile_groups OWNER TO postgres;

--
-- Name: core_baseuserprofile_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.core_baseuserprofile_groups_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.core_baseuserprofile_groups_id_seq OWNER TO postgres;

--
-- Name: core_baseuserprofile_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.core_baseuserprofile_groups_id_seq OWNED BY public.core_baseuserprofile_groups.id;


--
-- Name: core_baseuserprofile_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.core_baseuserprofile_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.core_baseuserprofile_id_seq OWNER TO postgres;

--
-- Name: core_baseuserprofile_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.core_baseuserprofile_id_seq OWNED BY public.core_baseuserprofile.id;


--
-- Name: core_baseuserprofile_passion; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.core_baseuserprofile_passion (
    id integer NOT NULL,
    baseuserprofile_id integer NOT NULL,
    hashtag_id integer NOT NULL
);


ALTER TABLE public.core_baseuserprofile_passion OWNER TO postgres;

--
-- Name: core_baseuserprofile_passion_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.core_baseuserprofile_passion_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.core_baseuserprofile_passion_id_seq OWNER TO postgres;

--
-- Name: core_baseuserprofile_passion_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.core_baseuserprofile_passion_id_seq OWNED BY public.core_baseuserprofile_passion.id;


--
-- Name: core_baseuserprofile_user_permissions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.core_baseuserprofile_user_permissions (
    id integer NOT NULL,
    baseuserprofile_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.core_baseuserprofile_user_permissions OWNER TO postgres;

--
-- Name: core_baseuserprofile_user_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.core_baseuserprofile_user_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.core_baseuserprofile_user_permissions_id_seq OWNER TO postgres;

--
-- Name: core_baseuserprofile_user_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.core_baseuserprofile_user_permissions_id_seq OWNED BY public.core_baseuserprofile_user_permissions.id;


--
-- Name: core_bookmarkarticle; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.core_bookmarkarticle (
    id integer NOT NULL,
    created_at timestamp with time zone NOT NULL,
    modified_at timestamp with time zone NOT NULL,
    article_id integer NOT NULL,
    user_id integer NOT NULL
);


ALTER TABLE public.core_bookmarkarticle OWNER TO postgres;

--
-- Name: core_bookmarkarticle_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.core_bookmarkarticle_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.core_bookmarkarticle_id_seq OWNER TO postgres;

--
-- Name: core_bookmarkarticle_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.core_bookmarkarticle_id_seq OWNED BY public.core_bookmarkarticle.id;


--
-- Name: core_category; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.core_category (
    id integer NOT NULL,
    created_at timestamp with time zone NOT NULL,
    modified_at timestamp with time zone NOT NULL,
    name character varying(255)
);


ALTER TABLE public.core_category OWNER TO postgres;

--
-- Name: core_category_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.core_category_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.core_category_id_seq OWNER TO postgres;

--
-- Name: core_category_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.core_category_id_seq OWNED BY public.core_category.id;


--
-- Name: core_categoryassociation; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.core_categoryassociation (
    id integer NOT NULL,
    child_cat_id integer NOT NULL,
    parent_cat_id integer NOT NULL
);


ALTER TABLE public.core_categoryassociation OWNER TO postgres;

--
-- Name: core_categoryassociation_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.core_categoryassociation_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.core_categoryassociation_id_seq OWNER TO postgres;

--
-- Name: core_categoryassociation_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.core_categoryassociation_id_seq OWNED BY public.core_categoryassociation.id;


--
-- Name: core_categorydefaultimage; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.core_categorydefaultimage (
    id integer NOT NULL,
    default_image_url character varying(200) NOT NULL,
    category_id integer NOT NULL
);


ALTER TABLE public.core_categorydefaultimage OWNER TO postgres;

--
-- Name: core_categorydefaultimage_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.core_categorydefaultimage_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.core_categorydefaultimage_id_seq OWNER TO postgres;

--
-- Name: core_categorydefaultimage_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.core_categorydefaultimage_id_seq OWNED BY public.core_categorydefaultimage.id;


--
-- Name: core_comment; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.core_comment (
    id integer NOT NULL,
    created_at timestamp with time zone NOT NULL,
    modified_at timestamp with time zone NOT NULL,
    comment character varying(250) NOT NULL,
    article_id integer NOT NULL,
    reply_id integer,
    user_id integer NOT NULL
);


ALTER TABLE public.core_comment OWNER TO postgres;

--
-- Name: core_comment_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.core_comment_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.core_comment_id_seq OWNER TO postgres;

--
-- Name: core_comment_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.core_comment_id_seq OWNED BY public.core_comment.id;


--
-- Name: core_dailydigest; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.core_dailydigest (
    id integer NOT NULL,
    created_at timestamp with time zone NOT NULL,
    modified_at timestamp with time zone NOT NULL,
    device_id integer NOT NULL,
    domain_id integer NOT NULL
);


ALTER TABLE public.core_dailydigest OWNER TO postgres;

--
-- Name: core_dailydigest_articles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.core_dailydigest_articles (
    id integer NOT NULL,
    dailydigest_id integer NOT NULL,
    article_id integer NOT NULL
);


ALTER TABLE public.core_dailydigest_articles OWNER TO postgres;

--
-- Name: core_dailydigest_articles_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.core_dailydigest_articles_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.core_dailydigest_articles_id_seq OWNER TO postgres;

--
-- Name: core_dailydigest_articles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.core_dailydigest_articles_id_seq OWNED BY public.core_dailydigest_articles.id;


--
-- Name: core_dailydigest_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.core_dailydigest_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.core_dailydigest_id_seq OWNER TO postgres;

--
-- Name: core_dailydigest_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.core_dailydigest_id_seq OWNED BY public.core_dailydigest.id;


--
-- Name: core_devices; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.core_devices (
    id integer NOT NULL,
    device_name character varying(255),
    device_id character varying(255),
    user_id integer
);


ALTER TABLE public.core_devices OWNER TO postgres;

--
-- Name: core_devices_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.core_devices_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.core_devices_id_seq OWNER TO postgres;

--
-- Name: core_devices_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.core_devices_id_seq OWNED BY public.core_devices.id;


--
-- Name: core_domain; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.core_domain (
    id integer NOT NULL,
    created_at timestamp with time zone NOT NULL,
    modified_at timestamp with time zone NOT NULL,
    domain_name character varying(255),
    domain_id character varying(255),
    default_image character varying(100) NOT NULL
);


ALTER TABLE public.core_domain OWNER TO postgres;

--
-- Name: core_domain_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.core_domain_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.core_domain_id_seq OWNER TO postgres;

--
-- Name: core_domain_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.core_domain_id_seq OWNED BY public.core_domain.id;


--
-- Name: core_draftmedia; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.core_draftmedia (
    id integer NOT NULL,
    created_at timestamp with time zone NOT NULL,
    modified_at timestamp with time zone NOT NULL,
    image character varying(100) NOT NULL
);


ALTER TABLE public.core_draftmedia OWNER TO postgres;

--
-- Name: core_draftmedia_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.core_draftmedia_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.core_draftmedia_id_seq OWNER TO postgres;

--
-- Name: core_draftmedia_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.core_draftmedia_id_seq OWNED BY public.core_draftmedia.id;


--
-- Name: core_hashtag; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.core_hashtag (
    id integer NOT NULL,
    name character varying(255) NOT NULL
);


ALTER TABLE public.core_hashtag OWNER TO postgres;

--
-- Name: core_hashtag_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.core_hashtag_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.core_hashtag_id_seq OWNER TO postgres;

--
-- Name: core_hashtag_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.core_hashtag_id_seq OWNED BY public.core_hashtag.id;


--
-- Name: core_menu; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.core_menu (
    id integer NOT NULL,
    domain_id integer,
    name_id integer NOT NULL,
    icon character varying(100)
);


ALTER TABLE public.core_menu OWNER TO postgres;

--
-- Name: core_menu_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.core_menu_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.core_menu_id_seq OWNER TO postgres;

--
-- Name: core_menu_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.core_menu_id_seq OWNED BY public.core_menu.id;


--
-- Name: core_menu_submenu; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.core_menu_submenu (
    id integer NOT NULL,
    menu_id integer NOT NULL,
    submenu_id integer NOT NULL
);


ALTER TABLE public.core_menu_submenu OWNER TO postgres;

--
-- Name: core_menu_submenu_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.core_menu_submenu_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.core_menu_submenu_id_seq OWNER TO postgres;

--
-- Name: core_menu_submenu_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.core_menu_submenu_id_seq OWNED BY public.core_menu_submenu.id;


--
-- Name: core_notification; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.core_notification (
    id integer NOT NULL,
    breaking_news boolean NOT NULL,
    daily_edition boolean NOT NULL,
    personalized boolean NOT NULL,
    device_id integer NOT NULL
);


ALTER TABLE public.core_notification OWNER TO postgres;

--
-- Name: core_notification_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.core_notification_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.core_notification_id_seq OWNER TO postgres;

--
-- Name: core_notification_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.core_notification_id_seq OWNED BY public.core_notification.id;


--
-- Name: core_relatedarticle; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.core_relatedarticle (
    id integer NOT NULL,
    created_at timestamp with time zone NOT NULL,
    modified_at timestamp with time zone NOT NULL,
    score double precision NOT NULL,
    related_id integer NOT NULL,
    source_id integer NOT NULL
);


ALTER TABLE public.core_relatedarticle OWNER TO postgres;

--
-- Name: core_relatedarticle_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.core_relatedarticle_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.core_relatedarticle_id_seq OWNER TO postgres;

--
-- Name: core_relatedarticle_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.core_relatedarticle_id_seq OWNED BY public.core_relatedarticle.id;


--
-- Name: core_scouteditem; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.core_scouteditem (
    id integer NOT NULL,
    title character varying(255) NOT NULL,
    url character varying(200) NOT NULL,
    category_id integer NOT NULL
);


ALTER TABLE public.core_scouteditem OWNER TO postgres;

--
-- Name: core_scouteditem_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.core_scouteditem_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.core_scouteditem_id_seq OWNER TO postgres;

--
-- Name: core_scouteditem_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.core_scouteditem_id_seq OWNED BY public.core_scouteditem.id;


--
-- Name: core_scoutfrontier; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.core_scoutfrontier (
    id integer NOT NULL,
    url character varying(200) NOT NULL,
    category_id integer NOT NULL
);


ALTER TABLE public.core_scoutfrontier OWNER TO postgres;

--
-- Name: core_scoutfrontier_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.core_scoutfrontier_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.core_scoutfrontier_id_seq OWNER TO postgres;

--
-- Name: core_scoutfrontier_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.core_scoutfrontier_id_seq OWNED BY public.core_scoutfrontier.id;


--
-- Name: core_socialaccount; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.core_socialaccount (
    id integer NOT NULL,
    provider character varying(200) NOT NULL,
    social_account_id character varying(200) NOT NULL,
    image_url character varying(250),
    user_id integer NOT NULL
);


ALTER TABLE public.core_socialaccount OWNER TO postgres;

--
-- Name: core_socialaccount_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.core_socialaccount_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.core_socialaccount_id_seq OWNER TO postgres;

--
-- Name: core_socialaccount_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.core_socialaccount_id_seq OWNED BY public.core_socialaccount.id;


--
-- Name: core_source; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.core_source (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    url character varying(200),
    active boolean NOT NULL
);


ALTER TABLE public.core_source OWNER TO postgres;

--
-- Name: core_source_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.core_source_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.core_source_id_seq OWNER TO postgres;

--
-- Name: core_source_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.core_source_id_seq OWNED BY public.core_source.id;


--
-- Name: core_submenu; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.core_submenu (
    id integer NOT NULL,
    name_id integer NOT NULL,
    icon character varying(100)
);


ALTER TABLE public.core_submenu OWNER TO postgres;

--
-- Name: core_submenu_hash_tags; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.core_submenu_hash_tags (
    id integer NOT NULL,
    submenu_id integer NOT NULL,
    hashtag_id integer NOT NULL
);


ALTER TABLE public.core_submenu_hash_tags OWNER TO postgres;

--
-- Name: core_submenu_hash_tags_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.core_submenu_hash_tags_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.core_submenu_hash_tags_id_seq OWNER TO postgres;

--
-- Name: core_submenu_hash_tags_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.core_submenu_hash_tags_id_seq OWNED BY public.core_submenu_hash_tags.id;


--
-- Name: core_submenu_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.core_submenu_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.core_submenu_id_seq OWNER TO postgres;

--
-- Name: core_submenu_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.core_submenu_id_seq OWNED BY public.core_submenu.id;


--
-- Name: core_trendingarticle; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.core_trendingarticle (
    id integer NOT NULL,
    created_at timestamp with time zone NOT NULL,
    modified_at timestamp with time zone NOT NULL,
    active boolean NOT NULL,
    score double precision NOT NULL,
    domain_id integer
);


ALTER TABLE public.core_trendingarticle OWNER TO postgres;

--
-- Name: core_trendingarticle_articles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.core_trendingarticle_articles (
    id integer NOT NULL,
    trendingarticle_id integer NOT NULL,
    article_id integer NOT NULL
);


ALTER TABLE public.core_trendingarticle_articles OWNER TO postgres;

--
-- Name: core_trendingarticle_articles_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.core_trendingarticle_articles_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.core_trendingarticle_articles_id_seq OWNER TO postgres;

--
-- Name: core_trendingarticle_articles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.core_trendingarticle_articles_id_seq OWNED BY public.core_trendingarticle_articles.id;


--
-- Name: core_trendingarticle_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.core_trendingarticle_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.core_trendingarticle_id_seq OWNER TO postgres;

--
-- Name: core_trendingarticle_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.core_trendingarticle_id_seq OWNED BY public.core_trendingarticle.id;


--
-- Name: core_trendinghashtag; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.core_trendinghashtag (
    id integer NOT NULL,
    name character varying(255) NOT NULL
);


ALTER TABLE public.core_trendinghashtag OWNER TO postgres;

--
-- Name: core_trendinghashtag_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.core_trendinghashtag_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.core_trendinghashtag_id_seq OWNER TO postgres;

--
-- Name: core_trendinghashtag_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.core_trendinghashtag_id_seq OWNED BY public.core_trendinghashtag.id;


--
-- Name: django_admin_log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.django_admin_log (
    id integer NOT NULL,
    action_time timestamp with time zone NOT NULL,
    object_id text,
    object_repr character varying(200) NOT NULL,
    action_flag smallint NOT NULL,
    change_message text NOT NULL,
    content_type_id integer,
    user_id integer NOT NULL,
    CONSTRAINT django_admin_log_action_flag_check CHECK ((action_flag >= 0))
);


ALTER TABLE public.django_admin_log OWNER TO postgres;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.django_admin_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_admin_log_id_seq OWNER TO postgres;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.django_admin_log_id_seq OWNED BY public.django_admin_log.id;


--
-- Name: django_content_type; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.django_content_type (
    id integer NOT NULL,
    app_label character varying(100) NOT NULL,
    model character varying(100) NOT NULL
);


ALTER TABLE public.django_content_type OWNER TO postgres;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.django_content_type_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_content_type_id_seq OWNER TO postgres;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.django_content_type_id_seq OWNED BY public.django_content_type.id;


--
-- Name: django_migrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.django_migrations (
    id integer NOT NULL,
    app character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    applied timestamp with time zone NOT NULL
);


ALTER TABLE public.django_migrations OWNER TO postgres;

--
-- Name: django_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.django_migrations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_migrations_id_seq OWNER TO postgres;

--
-- Name: django_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.django_migrations_id_seq OWNED BY public.django_migrations.id;


--
-- Name: django_session; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.django_session (
    session_key character varying(40) NOT NULL,
    session_data text NOT NULL,
    expire_date timestamp with time zone NOT NULL
);


ALTER TABLE public.django_session OWNER TO postgres;

--
-- Name: advertising_adgroup id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.advertising_adgroup ALTER COLUMN id SET DEFAULT nextval('public.advertising_adgroup_id_seq'::regclass);


--
-- Name: advertising_adgroup_category id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.advertising_adgroup_category ALTER COLUMN id SET DEFAULT nextval('public.advertising_adgroup_category_id_seq'::regclass);


--
-- Name: advertising_adtype id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.advertising_adtype ALTER COLUMN id SET DEFAULT nextval('public.advertising_adtype_id_seq'::regclass);


--
-- Name: advertising_advertisement id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.advertising_advertisement ALTER COLUMN id SET DEFAULT nextval('public.advertising_advertisement_id_seq'::regclass);


--
-- Name: advertising_campaign id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.advertising_campaign ALTER COLUMN id SET DEFAULT nextval('public.advertising_campaign_id_seq'::regclass);


--
-- Name: auth_group id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group ALTER COLUMN id SET DEFAULT nextval('public.auth_group_id_seq'::regclass);


--
-- Name: auth_group_permissions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group_permissions ALTER COLUMN id SET DEFAULT nextval('public.auth_group_permissions_id_seq'::regclass);


--
-- Name: auth_permission id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_permission ALTER COLUMN id SET DEFAULT nextval('public.auth_permission_id_seq'::regclass);


--
-- Name: captcha_captchastore id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.captcha_captchastore ALTER COLUMN id SET DEFAULT nextval('public.captcha_captchastore_id_seq'::regclass);


--
-- Name: core_article id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_article ALTER COLUMN id SET DEFAULT nextval('public.core_article_id_seq'::regclass);


--
-- Name: core_article_hash_tags id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_article_hash_tags ALTER COLUMN id SET DEFAULT nextval('public.core_article_hash_tags_id_seq'::regclass);


--
-- Name: core_articlelike id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_articlelike ALTER COLUMN id SET DEFAULT nextval('public.core_artilclelike_id_seq'::regclass);


--
-- Name: core_articlemedia id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_articlemedia ALTER COLUMN id SET DEFAULT nextval('public.core_articlemedia_id_seq'::regclass);


--
-- Name: core_articlerating id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_articlerating ALTER COLUMN id SET DEFAULT nextval('public.core_articlerating_id_seq'::regclass);


--
-- Name: core_baseuserprofile id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_baseuserprofile ALTER COLUMN id SET DEFAULT nextval('public.core_baseuserprofile_id_seq'::regclass);


--
-- Name: core_baseuserprofile_groups id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_baseuserprofile_groups ALTER COLUMN id SET DEFAULT nextval('public.core_baseuserprofile_groups_id_seq'::regclass);


--
-- Name: core_baseuserprofile_passion id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_baseuserprofile_passion ALTER COLUMN id SET DEFAULT nextval('public.core_baseuserprofile_passion_id_seq'::regclass);


--
-- Name: core_baseuserprofile_user_permissions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_baseuserprofile_user_permissions ALTER COLUMN id SET DEFAULT nextval('public.core_baseuserprofile_user_permissions_id_seq'::regclass);


--
-- Name: core_bookmarkarticle id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_bookmarkarticle ALTER COLUMN id SET DEFAULT nextval('public.core_bookmarkarticle_id_seq'::regclass);


--
-- Name: core_category id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_category ALTER COLUMN id SET DEFAULT nextval('public.core_category_id_seq'::regclass);


--
-- Name: core_categoryassociation id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_categoryassociation ALTER COLUMN id SET DEFAULT nextval('public.core_categoryassociation_id_seq'::regclass);


--
-- Name: core_categorydefaultimage id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_categorydefaultimage ALTER COLUMN id SET DEFAULT nextval('public.core_categorydefaultimage_id_seq'::regclass);


--
-- Name: core_comment id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_comment ALTER COLUMN id SET DEFAULT nextval('public.core_comment_id_seq'::regclass);


--
-- Name: core_dailydigest id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_dailydigest ALTER COLUMN id SET DEFAULT nextval('public.core_dailydigest_id_seq'::regclass);


--
-- Name: core_dailydigest_articles id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_dailydigest_articles ALTER COLUMN id SET DEFAULT nextval('public.core_dailydigest_articles_id_seq'::regclass);


--
-- Name: core_devices id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_devices ALTER COLUMN id SET DEFAULT nextval('public.core_devices_id_seq'::regclass);


--
-- Name: core_domain id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_domain ALTER COLUMN id SET DEFAULT nextval('public.core_domain_id_seq'::regclass);


--
-- Name: core_draftmedia id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_draftmedia ALTER COLUMN id SET DEFAULT nextval('public.core_draftmedia_id_seq'::regclass);


--
-- Name: core_hashtag id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_hashtag ALTER COLUMN id SET DEFAULT nextval('public.core_hashtag_id_seq'::regclass);


--
-- Name: core_menu id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_menu ALTER COLUMN id SET DEFAULT nextval('public.core_menu_id_seq'::regclass);


--
-- Name: core_menu_submenu id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_menu_submenu ALTER COLUMN id SET DEFAULT nextval('public.core_menu_submenu_id_seq'::regclass);


--
-- Name: core_notification id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_notification ALTER COLUMN id SET DEFAULT nextval('public.core_notification_id_seq'::regclass);


--
-- Name: core_relatedarticle id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_relatedarticle ALTER COLUMN id SET DEFAULT nextval('public.core_relatedarticle_id_seq'::regclass);


--
-- Name: core_scouteditem id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_scouteditem ALTER COLUMN id SET DEFAULT nextval('public.core_scouteditem_id_seq'::regclass);


--
-- Name: core_scoutfrontier id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_scoutfrontier ALTER COLUMN id SET DEFAULT nextval('public.core_scoutfrontier_id_seq'::regclass);


--
-- Name: core_socialaccount id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_socialaccount ALTER COLUMN id SET DEFAULT nextval('public.core_socialaccount_id_seq'::regclass);


--
-- Name: core_source id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_source ALTER COLUMN id SET DEFAULT nextval('public.core_source_id_seq'::regclass);


--
-- Name: core_submenu id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_submenu ALTER COLUMN id SET DEFAULT nextval('public.core_submenu_id_seq'::regclass);


--
-- Name: core_submenu_hash_tags id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_submenu_hash_tags ALTER COLUMN id SET DEFAULT nextval('public.core_submenu_hash_tags_id_seq'::regclass);


--
-- Name: core_trendingarticle id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_trendingarticle ALTER COLUMN id SET DEFAULT nextval('public.core_trendingarticle_id_seq'::regclass);


--
-- Name: core_trendingarticle_articles id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_trendingarticle_articles ALTER COLUMN id SET DEFAULT nextval('public.core_trendingarticle_articles_id_seq'::regclass);


--
-- Name: core_trendinghashtag id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_trendinghashtag ALTER COLUMN id SET DEFAULT nextval('public.core_trendinghashtag_id_seq'::regclass);


--
-- Name: django_admin_log id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_admin_log ALTER COLUMN id SET DEFAULT nextval('public.django_admin_log_id_seq'::regclass);


--
-- Name: django_content_type id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_content_type ALTER COLUMN id SET DEFAULT nextval('public.django_content_type_id_seq'::regclass);


--
-- Name: django_migrations id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_migrations ALTER COLUMN id SET DEFAULT nextval('public.django_migrations_id_seq'::regclass);


--
-- Data for Name: advertising_adgroup; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.advertising_adgroup (id, created_at, modified_at, is_active, campaign_id) FROM stdin;
1	2020-03-18 12:35:49.89519+05:30	2020-03-18 12:35:49.895217+05:30	t	2
\.


--
-- Data for Name: advertising_adgroup_category; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.advertising_adgroup_category (id, adgroup_id, category_id) FROM stdin;
1	1	253
\.


--
-- Data for Name: advertising_adtype; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.advertising_adtype (id, created_at, modified_at, type) FROM stdin;
1	2020-03-18 14:32:25.133071+05:30	2020-03-18 14:32:25.133094+05:30	CPC
2	2020-03-18 14:32:29.33113+05:30	2020-03-18 14:32:29.331151+05:30	CPM
\.


--
-- Data for Name: advertising_advertisement; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.advertising_advertisement (id, created_at, modified_at, ad_text, ad_url, media, is_active, impsn_limit, delivered, click_count, ad_type_id, adgroup_id) FROM stdin;
1	2020-03-18 14:37:13.048889+05:30	2020-03-18 19:25:06.838274+05:30	Test	https://www.business-standard.com/	undefined	t	0	0	0	1	1
2	2020-03-23 13:01:39.942503+05:30	2020-03-23 13:01:39.986476+05:30	test	http://www.cc.com	undefined	t	0	0	0	1	1
3	2020-03-23 13:09:28.846661+05:30	2020-03-23 13:09:28.880121+05:30	Test	http://www.test.com	undefined	t	0	0	0	1	1
\.


--
-- Data for Name: advertising_campaign; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.advertising_campaign (id, created_at, modified_at, name, is_active, daily_budget, max_bid, start_date, end_date, domain_id) FROM stdin;
1	2020-03-18 11:21:05.495738+05:30	2020-03-18 11:24:08.812327+05:30	Test Campaign	t	10.00	100.00	2020-03-18 11:20:58+05:30	2020-03-18 11:21:01+05:30	54
2	2020-03-18 12:34:47.372928+05:30	2020-03-18 12:34:47.372948+05:30	Test Campaign	t	10.00	100.00	2020-03-01 00:00:00+05:30	2020-03-03 00:00:00+05:30	1
\.


--
-- Data for Name: auth_group; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.auth_group (id, name) FROM stdin;
\.


--
-- Data for Name: auth_group_permissions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.auth_group_permissions (id, group_id, permission_id) FROM stdin;
\.


--
-- Data for Name: auth_permission; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.auth_permission (id, name, content_type_id, codename) FROM stdin;
\.


--
-- Data for Name: authtoken_token; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.authtoken_token (key, created, user_id) FROM stdin;
03987c62504db164d633b2e1eb47b3b28711135b	2020-03-17 18:38:16.815019+05:30	1
\.


--
-- Data for Name: captcha_captchastore; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.captcha_captchastore (id, challenge, response, hashkey, expiration) FROM stdin;
\.


--
-- Data for Name: core_article; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.core_article (id, created_at, modified_at, title, source_url, cover_image, blurb, full_text, published_on, active, hot, popular, avg_rating, view_count, rating_count, manually_edit, edited_on, indexed_on, spam, category_id, domain_id, edited_by_id, source_id, article_format, author_id, slug) FROM stdin;
\.


--
-- Data for Name: core_article_hash_tags; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.core_article_hash_tags (id, article_id, hashtag_id) FROM stdin;
\.


--
-- Data for Name: core_articlelike; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.core_articlelike (id, created_at, modified_at, is_like, article_id, user_id) FROM stdin;
\.


--
-- Data for Name: core_articlemedia; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.core_articlemedia (id, created_at, modified_at, category, url, video_url, article_id) FROM stdin;
\.


--
-- Data for Name: core_articlerating; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.core_articlerating (id, created_at, modified_at, rating, article_id) FROM stdin;
\.


--
-- Data for Name: core_baseuserprofile; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.core_baseuserprofile (id, password, last_login, is_superuser, username, first_name, last_name, email, is_staff, is_active, date_joined, domain_id, is_editor) FROM stdin;
1	pbkdf2_sha256$150000$LdTz8OkISWde$LGJB3ugb2alGn66ZydxeoRKAKw1JKyp7M1pr1xU9nnk=	2020-03-17 18:38:16+05:30	t	admin			admin@user.com	t	t	2020-03-17 18:37:50+05:30	1	t
\.


--
-- Data for Name: core_baseuserprofile_groups; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.core_baseuserprofile_groups (id, baseuserprofile_id, group_id) FROM stdin;
\.


--
-- Data for Name: core_baseuserprofile_passion; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.core_baseuserprofile_passion (id, baseuserprofile_id, hashtag_id) FROM stdin;
\.


--
-- Data for Name: core_baseuserprofile_user_permissions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.core_baseuserprofile_user_permissions (id, baseuserprofile_id, permission_id) FROM stdin;
\.


--
-- Data for Name: core_bookmarkarticle; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.core_bookmarkarticle (id, created_at, modified_at, article_id, user_id) FROM stdin;
\.


--
-- Data for Name: core_category; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.core_category (id, created_at, modified_at, name) FROM stdin;
253	2019-09-09 17:37:35.835+05:30	2019-09-09 17:37:35.835+05:30	Business Planning
252	2019-09-09 17:37:35.768+05:30	2019-09-09 17:37:35.768+05:30	Benchmarking
251	2019-09-09 17:37:35.698+05:30	2019-09-09 17:37:35.699+05:30	Sustainability
250	2019-09-09 17:37:35.63+05:30	2019-09-09 17:37:35.63+05:30	Capital Allocation
249	2019-09-09 17:37:35.566+05:30	2019-09-09 17:37:35.566+05:30	Operations
248	2019-09-09 17:37:35.502+05:30	2019-09-09 17:37:35.502+05:30	Global Business
247	2019-09-09 17:37:35.436+05:30	2019-09-09 17:37:35.436+05:30	The Economy
246	2019-09-09 17:37:35.369+05:30	2019-09-09 17:37:35.369+05:30	Profiles
245	2019-09-09 17:37:35.297+05:30	2019-09-09 17:37:35.297+05:30	Forecasting
244	2019-09-09 17:37:35.23+05:30	2019-09-09 17:37:35.23+05:30	Revenue Recognition
243	2019-09-09 17:37:35.155+05:30	2019-09-09 17:37:35.156+05:30	Lease Accounting
242	2019-09-09 17:37:35.088+05:30	2019-09-09 17:37:35.089+05:30	Expense Management
241	2019-09-09 17:37:35.017+05:30	2019-09-09 17:37:35.017+05:30	Disclosure
240	2019-09-09 17:37:34.949+05:30	2019-09-09 17:37:34.949+05:30	Auditing
239	2019-09-09 17:37:34.88+05:30	2019-09-09 17:37:34.88+05:30	Cost Management
238	2019-09-09 17:37:34.813+05:30	2019-09-09 17:37:34.813+05:30	GAAP and IFRS
237	2019-09-09 17:37:34.745+05:30	2019-09-09 17:37:34.745+05:30	Management Accounting
236	2019-09-09 17:37:34.677+05:30	2019-09-09 17:37:34.677+05:30	Cash Flow
235	2019-09-09 17:37:34.609+05:30	2019-09-09 17:37:34.609+05:30	Financial Reporting
234	2019-09-09 17:37:34.533+05:30	2019-09-09 17:37:34.533+05:30	Financial Performance
233	2019-09-09 17:37:34.465+05:30	2019-09-09 17:37:34.465+05:30	Budgeting
232	2019-09-09 17:37:34.397+05:30	2019-09-09 17:37:34.397+05:30	Business Performance Management
231	2019-09-09 17:37:34.073+05:30	2019-09-09 17:37:34.073+05:30	Financial Planning & Analysis
230	2019-09-09 17:37:33.984+05:30	2019-09-09 17:37:33.984+05:30	Information Security
229	2019-09-09 17:37:33.914+05:30	2019-09-09 17:37:33.914+05:30	Ethics
228	2019-09-09 17:37:33.847+05:30	2019-09-09 17:37:33.847+05:30	Governance
227	2019-09-09 17:37:33.78+05:30	2019-09-09 17:37:33.78+05:30	Supply Chain
226	2019-09-09 17:37:33.712+05:30	2019-09-09 17:37:33.712+05:30	Fraud
169	2019-05-13 16:50:54.277+05:30	2019-05-13 16:50:54.277+05:30	Europe
168	2019-05-13 16:47:24.04+05:30	2019-05-13 16:47:24.04+05:30	Environment
167	2019-05-13 16:47:15.903+05:30	2019-05-13 16:47:15.903+05:30	Entrepreneurship
166	2019-05-13 16:47:10.032+05:30	2019-05-13 16:47:10.032+05:30	Career
165	2019-05-13 16:46:49.745+05:30	2019-05-13 16:46:49.746+05:30	Media
164	2019-05-13 16:46:17.545+05:30	2019-05-13 16:46:17.545+05:30	Earning Reports
162	2019-04-30 15:54:21.709+05:30	2019-04-30 15:54:21.709+05:30	FinTech
157	2019-03-28 13:30:50.278+05:30	2019-03-28 13:30:50.278+05:30	Automotive Industry
159	2019-04-23 17:58:57.28+05:30	2019-04-23 17:58:57.28+05:30	IPO
729	2020-01-05 16:52:42.118+05:30	2020-01-05 16:52:42.118+05:30	Best Supply Chain Practices
728	2020-01-05 16:47:02.577+05:30	2020-01-05 16:47:02.577+05:30	Economic and Political Weekly
727	2020-01-05 09:06:52.395+05:30	2020-01-05 09:06:52.395+05:30	Budget 2018–19
726	2020-01-05 05:48:35.407+05:30	2020-01-05 05:48:35.407+05:30	India’s Democracy Today
725	2020-01-05 05:21:10.741+05:30	2020-01-05 05:21:10.741+05:30	Punjab—Exploring Prospects
724	2020-01-05 05:04:58.465+05:30	2020-01-05 05:04:58.465+05:30	Core’s Economics Textbook
723	2020-01-05 04:47:48.116+05:30	2020-01-05 04:47:48.116+05:30	Budget 2016–17
722	2020-01-05 03:32:14.43+05:30	2020-01-05 03:32:14.43+05:30	Uttar Pradesh—Vortex of Change
721	2020-01-05 03:13:57.713+05:30	2020-01-05 03:13:57.713+05:30	Budget 2015–16
720	2020-01-05 03:09:44.756+05:30	2020-01-05 03:09:44.756+05:30	Comment
719	2020-01-05 03:04:25.558+05:30	2020-01-05 03:04:25.558+05:30	Civil Liberties
718	2020-01-05 03:02:11.401+05:30	2020-01-05 03:02:11.401+05:30	Prespectives
717	2020-01-05 02:58:49.582+05:30	2020-01-05 02:58:49.582+05:30	Das Kapital, Vol 1—150 Years
716	2020-01-05 02:56:45.473+05:30	2020-01-05 02:56:45.473+05:30	Annual Number
715	2020-01-05 02:55:59.819+05:30	2020-01-05 02:55:59.819+05:30	Banking and Finance
714	2020-01-05 02:55:31.151+05:30	2020-01-05 02:55:31.151+05:30	Statistics
713	2020-01-05 02:55:27.412+05:30	2020-01-05 02:55:27.412+05:30	Postscript
712	2020-01-05 02:54:41.826+05:30	2020-01-05 02:54:41.826+05:30	Margin Speak
711	2020-01-05 02:54:38.743+05:30	2020-01-05 02:54:38.743+05:30	Current Statistics
710	2020-01-05 02:54:35.701+05:30	2020-01-05 02:54:35.701+05:30	Law and Society
709	2020-01-05 02:53:55.071+05:30	2020-01-05 02:53:55.071+05:30	Letters
708	2020-01-05 02:53:45.391+05:30	2020-01-05 02:53:45.391+05:30	Perspectives
707	2020-01-05 02:53:38.007+05:30	2020-01-05 02:53:38.007+05:30	Special Articles
706	2020-01-05 02:53:36.427+05:30	2020-01-05 02:53:36.427+05:30	Editorials
705	2020-01-05 02:53:34.114+05:30	2020-01-05 02:53:34.114+05:30	Discussion
704	2020-01-05 02:53:31.859+05:30	2020-01-05 02:53:31.859+05:30	Commentary
703	2020-01-05 02:53:25.215+05:30	2020-01-05 02:53:25.215+05:30	Solar Quarter
702	2020-01-05 02:50:04.307+05:30	2020-01-05 02:50:04.307+05:30	Licensing Corner
701	2020-01-05 02:20:05.443+05:30	2020-01-05 02:20:05.443+05:30	Character
700	2020-01-05 02:18:40.234+05:30	2020-01-05 02:18:40.234+05:30	E-Commerce
699	2020-01-05 02:17:41.231+05:30	2020-01-05 02:17:41.231+05:30	Publishing
698	2020-01-05 02:17:35.306+05:30	2020-01-05 02:17:35.306+05:30	Big Move
697	2020-01-05 02:17:05.5+05:30	2020-01-05 02:17:05.5+05:30	Know-How
696	2020-01-05 02:16:47.26+05:30	2020-01-05 02:16:47.26+05:30	Art & Design
695	2020-01-05 02:16:27.782+05:30	2020-01-05 02:16:27.782+05:30	TV & Films
694	2020-01-05 02:16:21.91+05:30	2020-01-05 02:16:21.91+05:30	Corporate Brand
693	2020-01-05 02:16:18.237+05:30	2020-01-05 02:16:18.237+05:30	Collaborations
692	2020-01-05 02:16:09.012+05:30	2020-01-05 02:16:09.012+05:30	Licensing
691	2020-01-05 02:16:07.317+05:30	2020-01-05 02:16:07.318+05:30	The Teenager Today
690	2020-01-05 01:53:31.355+05:30	2020-01-05 01:53:31.355+05:30	App Appeal
689	2020-01-05 01:52:01.342+05:30	2020-01-05 01:52:01.342+05:30	Gadgets
688	2020-01-05 01:51:48.954+05:30	2020-01-05 01:51:48.955+05:30	Fun Facts
687	2020-01-05 01:51:42.242+05:30	2020-01-05 01:51:42.242+05:30	Soul Strings
686	2020-01-05 01:51:22.712+05:30	2020-01-05 01:51:22.712+05:30	Health and Fitness
685	2020-01-05 01:51:18.93+05:30	2020-01-05 01:51:18.93+05:30	Q & A
684	2020-01-05 01:51:18.189+05:30	2020-01-05 01:51:18.19+05:30	Life Lessons
683	2020-01-05 01:51:16.012+05:30	2020-01-05 01:51:16.012+05:30	Counselling
682	2020-01-05 01:51:08.05+05:30	2020-01-05 01:51:08.05+05:30	Teen Space
681	2020-01-05 01:51:07.282+05:30	2020-01-05 01:51:07.282+05:30	Music
680	2020-01-05 01:51:05.572+05:30	2020-01-05 01:51:05.572+05:30	Retail Jewellers India
679	2020-01-05 01:29:39.931+05:30	2020-01-05 01:29:39.931+05:30	Sales
678	2020-01-05 01:28:32.338+05:30	2020-01-05 01:28:32.338+05:30	RJ Market Watch
677	2020-01-05 01:28:31.611+05:30	2020-01-05 01:28:31.611+05:30	Retail Jewellers
676	2020-01-05 01:28:29.011+05:30	2020-01-05 01:28:29.011+05:30	Diabetes Health
675	2020-01-05 01:26:47.798+05:30	2020-01-05 01:26:47.798+05:30	Diabetes Care
674	2020-01-05 01:26:42.668+05:30	2020-01-05 01:26:42.668+05:30	Light Reading
673	2020-01-05 01:26:40.086+05:30	2020-01-05 01:26:40.086+05:30	Living with Diabetes
672	2020-01-05 01:26:39.077+05:30	2020-01-05 01:26:39.077+05:30	EPR Magazine
671	2020-01-05 00:39:29.813+05:30	2020-01-05 00:39:29.813+05:30	Tech View
670	2020-01-05 00:38:07.869+05:30	2020-01-05 00:38:07.869+05:30	Power Brand
669	2020-01-05 00:38:02.806+05:30	2020-01-05 00:38:02.806+05:30	Crains Detroit
668	2020-01-04 03:16:03.843+05:30	2020-01-04 03:16:03.843+05:30	Courts
667	2020-01-04 00:50:31.915+05:30	2020-01-04 00:50:31.916+05:30	Jobs
160	2019-04-24 14:17:35.875+05:30	2019-04-24 14:17:35.875+05:30	India
158	2019-04-23 16:51:36.832+05:30	2019-04-23 16:51:36.832+05:30	Funding
666	2020-01-03 23:59:40.11+05:30	2020-01-03 23:59:40.11+05:30	Entertainment
665	2020-01-03 23:55:57.309+05:30	2020-01-03 23:55:57.309+05:30	Politics
664	2020-01-03 23:36:46.376+05:30	2020-01-03 23:36:46.376+05:30	Transportation
663	2020-01-03 23:26:41.17+05:30	2020-01-03 23:26:41.17+05:30	Editorial
662	2020-01-03 23:19:59.534+05:30	2020-01-03 23:19:59.534+05:30	Voices
661	2020-01-03 23:19:31.366+05:30	2020-01-03 23:19:31.366+05:30	Charlotte Magazine
660	2020-01-03 20:52:57.365+05:30	2020-01-03 20:52:57.366+05:30	The Buzz
659	2020-01-03 20:52:53.847+05:30	2020-01-03 20:52:53.847+05:30	Life & Style
658	2020-01-03 20:52:53.149+05:30	2020-01-03 20:52:53.149+05:30	Homes
657	2020-01-03 20:52:46.869+05:30	2020-01-03 20:52:46.869+05:30	Talks
656	2020-01-03 20:52:43.311+05:30	2020-01-03 20:52:43.311+05:30	WeddingsIn
655	2020-01-03 20:52:42.641+05:30	2020-01-03 20:52:42.641+05:30	Curated
654	2020-01-03 20:52:39.732+05:30	2020-01-03 20:52:39.732+05:30	I 4 Business
653	2020-01-03 20:34:50.356+05:30	2020-01-03 20:34:50.356+05:30	Partner Profiles
652	2020-01-03 20:32:20.697+05:30	2020-01-03 20:32:20.697+05:30	Current Issue
651	2020-01-03 20:31:46.865+05:30	2020-01-03 20:31:46.865+05:30	Best Practice
650	2020-01-03 20:29:57.844+05:30	2020-01-03 20:29:57.844+05:30	Inspiring Success
649	2020-01-03 20:29:48.314+05:30	2020-01-03 20:29:48.314+05:30	Sales and Marketing
648	2020-01-03 20:29:45.242+05:30	2020-01-03 20:29:45.242+05:30	Tampa Bay Business and Wealth
647	2020-01-03 20:25:03.012+05:30	2020-01-03 20:25:03.012+05:30	Food & Drink
646	2020-01-03 20:24:45.219+05:30	2020-01-03 20:24:45.219+05:30	HealthCare
645	2020-01-03 20:24:42.533+05:30	2020-01-03 20:24:42.533+05:30	Great Places
644	2020-01-03 20:24:41.861+05:30	2020-01-03 20:24:41.861+05:30	Peoples
643	2020-01-03 20:24:36.506+05:30	2020-01-03 20:24:36.506+05:30	One Liners
642	2020-01-03 20:24:34.342+05:30	2020-01-03 20:24:34.342+05:30	Publisher's Letter
641	2020-01-03 20:24:33.48+05:30	2020-01-03 20:24:33.48+05:30	Hawaii Business
640	2020-01-03 19:55:22.654+05:30	2020-01-03 19:55:22.655+05:30	Agriculture
639	2020-01-03 19:55:06.29+05:30	2020-01-03 19:55:06.29+05:30	Sports
638	2020-01-03 19:54:38.207+05:30	2020-01-03 19:54:38.207+05:30	Success Stories
637	2020-01-03 19:54:12.944+05:30	2020-01-03 19:54:12.944+05:30	Arts & Culture
636	2020-01-03 19:54:12.205+05:30	2020-01-03 19:54:12.205+05:30	Government
635	2020-01-03 19:53:59.687+05:30	2020-01-03 19:53:59.687+05:30	Cuisine Oir Magazine
634	2020-01-03 19:46:28.675+05:30	2020-01-03 19:46:28.675+05:30	Print Issues
633	2020-01-03 19:45:37.396+05:30	2020-01-03 19:45:37.396+05:30	World News
632	2020-01-03 19:45:08.491+05:30	2020-01-03 19:45:08.491+05:30	Entertaining
631	2020-01-03 19:44:57.864+05:30	2020-01-03 19:44:57.864+05:30	Book Grub
630	2020-01-03 19:44:46.866+05:30	2020-01-03 19:44:46.866+05:30	Etiquette
629	2020-01-03 19:44:33.112+05:30	2020-01-03 19:44:33.112+05:30	CN Review
628	2020-01-03 19:44:31.493+05:30	2020-01-03 19:44:31.493+05:30	Community Rec Magazine
627	2020-01-03 19:42:14.376+05:30	2020-01-03 19:42:14.376+05:30	Programming
626	2020-01-03 19:42:11.741+05:30	2020-01-03 19:42:11.741+05:30	Supplier News
625	2020-01-03 19:41:52.366+05:30	2020-01-03 19:41:52.367+05:30	Indian Business Journal
624	2020-01-03 19:41:50.511+05:30	2020-01-03 19:41:50.511+05:30	Facts For You
623	2020-01-03 19:41:44.374+05:30	2020-01-03 19:41:44.374+05:30	Star Talk
622	2020-01-03 19:41:43.705+05:30	2020-01-03 19:41:43.705+05:30	SPECIAL REPORT
621	2020-01-03 19:41:41.72+05:30	2020-01-03 19:41:41.72+05:30	COVER FEATURE
620	2020-01-03 19:41:41.113+05:30	2020-01-03 19:41:41.113+05:30	Spiritual Corner
619	2020-01-03 19:41:40.486+05:30	2020-01-03 19:41:40.486+05:30	HOT SEAT
618	2020-01-03 19:41:39.828+05:30	2020-01-03 19:41:39.828+05:30	KNOWLEDGE ZONE
617	2020-01-03 19:41:39.182+05:30	2020-01-03 19:41:39.182+05:30	Reader's Lounge
616	2020-01-03 19:41:38.517+05:30	2020-01-03 19:41:38.517+05:30	Management Mantra
615	2020-01-03 19:41:37.857+05:30	2020-01-03 19:41:37.857+05:30	Global Wrap-Up
614	2020-01-03 19:41:37.193+05:30	2020-01-03 19:41:37.193+05:30	Corporate Affairs
613	2020-01-03 19:41:34.406+05:30	2020-01-03 19:41:34.406+05:30	News Round-Up
612	2020-01-03 19:41:33.746+05:30	2020-01-03 19:41:33.746+05:30	View Point
611	2020-01-03 19:41:33.009+05:30	2020-01-03 19:41:33.009+05:30	Pets Plus Magazine
610	2020-01-03 19:13:52.042+05:30	2020-01-03 19:13:52.042+05:30	Do You Or Don't You
609	2020-01-03 19:11:25.76+05:30	2020-01-03 19:11:25.76+05:30	Manager's To Do
608	2020-01-03 19:10:04.108+05:30	2020-01-03 19:10:04.108+05:30	Benchmarks
607	2020-01-03 19:09:57.21+05:30	2020-01-03 19:09:57.21+05:30	Pets
606	2020-01-03 19:09:52.343+05:30	2020-01-03 19:09:52.343+05:30	Press Releases
605	2020-01-03 19:09:51.056+05:30	2020-01-03 19:09:51.056+05:30	Headlines
604	2020-01-03 19:09:49.749+05:30	2020-01-03 19:09:49.749+05:30	Gigabit Magazine
603	2020-01-03 18:48:09.109+05:30	2020-01-03 18:48:09.109+05:30	Procurement
602	2020-01-03 18:47:45.558+05:30	2020-01-03 18:47:45.558+05:30	Data Centres
601	2020-01-03 18:47:28.423+05:30	2020-01-03 18:47:28.423+05:30	Health
600	2020-01-03 18:46:43.425+05:30	2020-01-03 18:46:43.425+05:30	QSR Magazine
599	2020-01-03 12:19:45.159+05:30	2020-01-03 12:19:45.159+05:30	Marketing & Promotions
598	2020-01-03 12:13:11.008+05:30	2020-01-03 12:13:11.008+05:30	Outside Insights
597	2020-01-03 12:12:19.959+05:30	2020-01-03 12:12:19.959+05:30	Franchising
596	2020-01-03 12:12:10.994+05:30	2020-01-03 12:12:10.994+05:30	Reports
595	2020-01-02 21:12:23.702+05:30	2020-01-02 21:12:23.702+05:30	Tube Filter
594	2020-01-02 17:43:26.218+05:30	2020-01-02 17:43:26.218+05:30	Cover Stories
593	2020-01-02 15:55:44.537+05:30	2020-01-02 15:55:44.538+05:30	Data
592	2020-01-02 15:55:12.298+05:30	2020-01-02 15:55:12.298+05:30	Branded Entertainment
591	2020-01-02 15:54:47.83+05:30	2020-01-02 15:54:47.83+05:30	Charts
590	2020-01-02 15:54:43.386+05:30	2020-01-02 15:54:43.386+05:30	Creators Going Pro
589	2020-01-02 15:54:18.849+05:30	2020-01-02 15:54:18.849+05:30	Millionaires
588	2020-01-02 15:53:55.8+05:30	2020-01-02 15:53:55.8+05:30	YouTube
587	2020-01-02 15:24:33.901+05:30	2020-01-02 15:24:33.901+05:30	Women in Supply Chain
586	2020-01-02 15:22:54.168+05:30	2020-01-02 15:22:54.168+05:30	Energy & Infrastructure
585	2020-01-02 15:20:38.552+05:30	2020-01-02 15:20:38.552+05:30	Industry Updates
584	2020-01-02 15:20:36.873+05:30	2020-01-02 15:20:36.873+05:30	WDI-Manufacturer’s Representatives
583	2020-01-02 15:20:30.189+05:30	2020-01-02 15:20:30.189+05:30	Food, Beverage & Hospitality
582	2020-01-02 15:19:18.838+05:30	2020-01-02 15:19:18.838+05:30	Manufacturing & Distribution
581	2020-01-02 15:19:14.354+05:30	2020-01-02 15:19:14.354+05:30	Transportation and logistics
580	2020-01-02 15:19:13.365+05:30	2020-01-02 15:19:13.365+05:30	Solutions
578	2019-09-30 10:25:39.344+05:30	2019-09-30 10:25:39.344+05:30	Construction World
577	2019-09-30 10:19:02.424+05:30	2019-09-30 10:19:02.424+05:30	Arbitration
576	2019-09-30 10:18:59.428+05:30	2019-09-30 10:18:59.428+05:30	Civic Sense
575	2019-09-30 10:18:53.799+05:30	2019-09-30 10:18:53.799+05:30	Current Affairs
574	2019-09-30 10:18:52.731+05:30	2019-09-30 10:18:52.731+05:30	Specials
573	2019-09-30 10:18:52.72+05:30	2019-09-30 10:18:52.72+05:30	Feature
572	2019-09-30 10:18:52.668+05:30	2019-09-30 10:18:52.668+05:30	Desk
571	2019-09-30 10:18:52.194+05:30	2019-09-30 10:18:52.194+05:30	Communication Feature
570	2019-09-30 10:18:52.17+05:30	2019-09-30 10:18:52.17+05:30	Construction and Building
569	2019-09-24 10:09:58.02+05:30	2019-09-24 10:09:58.02+05:30	Print Week
568	2019-09-24 10:05:34.966+05:30	2019-09-24 10:05:34.966+05:30	Product
567	2019-09-24 10:05:22.242+05:30	2019-09-24 10:05:22.242+05:30	Gallery
566	2019-09-23 13:05:25.747+05:30	2019-09-23 13:05:25.747+05:30	Business Goa
565	2019-09-23 13:03:56.637+05:30	2019-09-23 13:03:56.637+05:30	Campus
564	2019-09-23 13:03:56.463+05:30	2019-09-23 13:03:56.463+05:30	Lady Power
563	2019-09-23 13:03:56.313+05:30	2019-09-23 13:03:56.313+05:30	Knowledge
562	2019-09-23 13:03:56.305+05:30	2019-09-23 13:03:56.305+05:30	Biz Bytes
561	2019-09-23 13:03:56.294+05:30	2019-09-23 13:03:56.294+05:30	Corpo Scan
560	2019-09-23 13:03:56.286+05:30	2019-09-23 13:03:56.287+05:30	Newsmakers
559	2019-09-23 13:03:56.143+05:30	2019-09-23 13:03:56.143+05:30	Focus Goa
558	2019-09-23 13:03:56.11+05:30	2019-09-23 13:03:56.11+05:30	Festive Special
557	2019-09-20 16:33:54.615+05:30	2019-09-20 16:33:54.615+05:30	Maritime Gateway
556	2019-09-20 13:00:34.527+05:30	2019-09-20 13:00:34.527+05:30	Tyre Asia
555	2019-09-20 12:58:12.224+05:30	2019-09-20 12:58:12.224+05:30	Limelight
554	2019-09-20 12:58:12.151+05:30	2019-09-20 12:58:12.151+05:30	Thoughts
553	2019-09-20 12:58:11.871+05:30	2019-09-20 12:58:11.871+05:30	Retread
552	2019-09-20 12:58:11.68+05:30	2019-09-20 12:58:11.68+05:30	Green
551	2019-09-20 12:58:11.672+05:30	2019-09-20 12:58:11.672+05:30	Views
550	2019-09-20 12:58:11.558+05:30	2019-09-20 12:58:11.558+05:30	Company Watch
549	2019-09-20 12:58:11.53+05:30	2019-09-20 12:58:11.53+05:30	Rubber
548	2019-09-19 16:58:55.461+05:30	2019-09-19 16:58:55.461+05:30	Rubber Asia
547	2019-09-19 16:57:02.999+05:30	2019-09-19 16:57:02.999+05:30	Plantation
546	2019-09-19 16:57:02.178+05:30	2019-09-19 16:57:02.178+05:30	Market Watch
545	2019-09-19 16:57:01.942+05:30	2019-09-19 16:57:01.942+05:30	Industry
544	2019-09-19 16:57:01.919+05:30	2019-09-19 16:57:01.919+05:30	Slider
543	2019-09-19 12:27:24.008+05:30	2019-09-19 12:27:24.008+05:30	Motor India Online
542	2019-09-19 12:22:47.474+05:30	2019-09-19 12:22:47.474+05:30	Women of Mettle
541	2019-09-19 12:22:46.422+05:30	2019-09-19 12:22:46.422+05:30	Emission Control
540	2019-09-19 12:22:45.13+05:30	2019-09-19 12:22:45.13+05:30	Appointments
539	2019-09-19 12:22:43.998+05:30	2019-09-19 12:22:43.998+05:30	Technology and R&D
538	2019-09-19 12:22:42.701+05:30	2019-09-19 12:22:42.701+05:30	Exclusive
537	2019-09-19 12:22:42.568+05:30	2019-09-19 12:22:42.568+05:30	Industry News
536	2019-09-19 12:22:42.484+05:30	2019-09-19 12:22:42.484+05:30	Aftermarket
535	2019-09-19 12:22:42.303+05:30	2019-09-19 12:22:42.303+05:30	Construction Equipment
534	2019-09-19 12:22:42.286+05:30	2019-09-19 12:22:42.286+05:30	Logistics
533	2019-09-19 12:22:42.208+05:30	2019-09-19 12:22:42.208+05:30	Newsletters
532	2019-09-19 12:22:42.188+05:30	2019-09-19 12:22:42.188+05:30	E-Magazine
531	2019-09-19 12:22:42.165+05:30	2019-09-19 12:22:42.165+05:30	Components
530	2019-09-19 12:22:42.112+05:30	2019-09-19 12:22:42.113+05:30	Vehicles
529	2019-09-19 12:01:54.237+05:30	2019-09-19 12:01:54.237+05:30	SME Channels
528	2019-09-19 11:56:18.684+05:30	2019-09-19 11:56:18.684+05:30	Quote
527	2019-09-19 11:56:16.946+05:30	2019-09-19 11:56:16.946+05:30	Post Budget
526	2019-09-19 11:49:40.499+05:30	2019-09-19 11:49:40.499+05:30	Data Centre
525	2019-09-19 11:49:40.395+05:30	2019-09-19 11:49:40.395+05:30	Women Empowerment
524	2019-09-19 11:49:39.177+05:30	2019-09-19 11:49:39.177+05:30	Future Technology
523	2019-09-19 11:49:38.981+05:30	2019-09-19 11:49:38.981+05:30	Review
522	2019-09-19 11:49:38.556+05:30	2019-09-19 11:49:38.556+05:30	Channel Mentors
521	2019-09-19 11:49:38.107+05:30	2019-09-19 11:49:38.107+05:30	Channel Leaders
520	2019-09-19 11:49:38.092+05:30	2019-09-19 11:49:38.092+05:30	Unified Communications
519	2019-09-19 11:49:38.024+05:30	2019-09-19 11:49:38.024+05:30	Software News
518	2019-09-19 11:49:37.904+05:30	2019-09-19 11:49:37.904+05:30	Partner Corner
517	2019-09-19 11:49:37.796+05:30	2019-09-19 11:49:37.796+05:30	Start Up
516	2019-09-19 11:49:37.697+05:30	2019-09-19 11:49:37.697+05:30	Imaging Solutions
515	2019-09-19 11:49:37.634+05:30	2019-09-19 11:49:37.634+05:30	Cloud Computing
514	2019-09-19 11:49:37.601+05:30	2019-09-19 11:49:37.601+05:30	Executives Movement
513	2019-09-19 11:49:37.589+05:30	2019-09-19 11:49:37.589+05:30	Super 50
512	2019-09-19 11:49:37.583+05:30	2019-09-19 11:49:37.583+05:30	Guest Article
511	2019-09-19 11:49:37.493+05:30	2019-09-19 11:49:37.493+05:30	Surveillance
510	2019-09-19 11:49:37.436+05:30	2019-09-19 11:49:37.436+05:30	Awards
509	2019-09-19 11:49:37.427+05:30	2019-09-19 11:49:37.427+05:30	Pick of the Week
508	2019-09-19 11:49:37.391+05:30	2019-09-19 11:49:37.391+05:30	Warranty and Services
507	2019-09-19 11:49:37.329+05:30	2019-09-19 11:49:37.329+05:30	Accessories
506	2019-09-19 11:49:37.28+05:30	2019-09-19 11:49:37.28+05:30	Corporate News
505	2019-09-18 18:34:14.999+05:30	2019-09-18 18:34:14.999+05:30	Startup 360
504	2019-09-18 18:32:07.811+05:30	2019-09-18 18:32:07.811+05:30	Business Strategy
503	2019-09-18 18:32:07.441+05:30	2019-09-18 18:32:07.441+05:30	Finance & Banking
502	2019-09-18 18:32:07.219+05:30	2019-09-18 18:32:07.219+05:30	Acquistions
501	2019-09-18 18:32:07.141+05:30	2019-09-18 18:32:07.141+05:30	Ecommerce
500	2019-09-18 18:32:07.135+05:30	2019-09-18 18:32:07.135+05:30	Startup Of The Month
499	2019-09-18 18:32:07.045+05:30	2019-09-18 18:32:07.045+05:30	Startup Stories
498	2019-09-18 17:56:36.85+05:30	2019-09-18 17:56:36.85+05:30	Banking Frontiers
497	2019-09-18 17:52:56.942+05:30	2019-09-18 17:52:56.943+05:30	Editor's Blog
496	2019-09-18 17:52:56.479+05:30	2019-09-18 17:52:56.479+05:30	Cooperative
495	2019-09-18 17:52:56.352+05:30	2019-09-18 17:52:56.352+05:30	Issue Highlights
494	2019-09-18 17:52:56.026+05:30	2019-09-18 17:52:56.026+05:30	Cover Feature
493	2019-09-18 17:52:55.623+05:30	2019-09-18 17:52:55.623+05:30	Project Pipeline
492	2019-09-14 13:43:18.989+05:30	2019-09-14 13:43:18.99+05:30	TTT
491	2019-09-14 13:41:42.028+05:30	2019-09-14 13:41:42.028+05:30	TTT
490	2019-09-14 12:55:39.364+05:30	2019-09-14 12:55:39.364+05:30	Auto CarPro
489	2019-09-14 12:33:07.026+05:30	2019-09-14 12:33:07.026+05:30	Event
488	2019-09-09 17:37:55.943+05:30	2019-09-09 17:37:55.943+05:30	Promoted
487	2019-09-09 17:37:55.874+05:30	2019-09-09 17:37:55.874+05:30	Products Buy
486	2019-09-09 17:37:55.808+05:30	2019-09-09 17:37:55.808+05:30	Advice
485	2019-09-09 17:37:55.674+05:30	2019-09-09 17:37:55.674+05:30	Association
484	2019-09-09 17:37:55.565+05:30	2019-09-09 17:37:55.565+05:30	Show Case
483	2019-09-09 17:37:55.477+05:30	2019-09-09 17:37:55.477+05:30	National News
482	2019-09-09 17:37:55.408+05:30	2019-09-09 17:37:55.408+05:30	Quick Reads
481	2019-09-09 17:37:55.335+05:30	2019-09-09 17:37:55.335+05:30	Blogs
480	2019-09-09 17:37:55.266+05:30	2019-09-09 17:37:55.267+05:30	Start-ups
479	2019-09-09 17:37:55.175+05:30	2019-09-09 17:37:55.175+05:30	Special
478	2019-09-09 17:37:55.082+05:30	2019-09-09 17:37:55.082+05:30	Segments
477	2019-09-09 17:37:54.982+05:30	2019-09-09 17:37:54.982+05:30	In-Focus
476	2019-09-09 17:37:54.913+05:30	2019-09-09 17:37:54.913+05:30	Food-Retail
475	2019-09-09 17:37:54.823+05:30	2019-09-09 17:37:54.823+05:30	Spotlight
474	2019-09-09 17:37:54.755+05:30	2019-09-09 17:37:54.755+05:30	Bakery Focus
473	2019-09-09 17:37:54.689+05:30	2019-09-09 17:37:54.689+05:30	Chef-Platter
472	2019-09-09 17:37:54.618+05:30	2019-09-09 17:37:54.618+05:30	Star Spotlight
471	2019-09-09 17:37:54.53+05:30	2019-09-09 17:37:54.53+05:30	Restaurant of the week
470	2019-09-09 17:37:54.463+05:30	2019-09-09 17:37:54.463+05:30	Editor's Side
469	2019-09-09 17:37:54.393+05:30	2019-09-09 17:37:54.393+05:30	Wellness Worls
468	2019-09-09 17:37:54.322+05:30	2019-09-09 17:37:54.322+05:30	High Spirits
467	2019-09-09 17:37:54.232+05:30	2019-09-09 17:37:54.232+05:30	Edge
466	2019-09-09 17:37:54.163+05:30	2019-09-09 17:37:54.163+05:30	Product-Tracker
465	2019-09-09 17:37:54.074+05:30	2019-09-09 17:37:54.074+05:30	Corporate Ladder
464	2019-09-09 17:37:54.006+05:30	2019-09-09 17:37:54.006+05:30	Weekend
463	2019-09-09 17:37:53.897+05:30	2019-09-09 17:37:53.897+05:30	Management
462	2019-09-09 17:37:53.83+05:30	2019-09-09 17:37:53.83+05:30	Archive
461	2019-09-09 17:37:53.747+05:30	2019-09-09 17:37:53.748+05:30	Market
460	2019-09-09 17:37:53.618+05:30	2019-09-09 17:37:53.618+05:30	Latest Updates
459	2019-09-09 17:37:53.446+05:30	2019-09-09 17:37:53.446+05:30	Case Studies
458	2019-09-09 17:37:53.246+05:30	2019-09-09 17:37:53.246+05:30	Science
457	2019-09-09 17:37:53.009+05:30	2019-09-09 17:37:53.009+05:30	Viewpoint
456	2019-09-09 17:37:52.867+05:30	2019-09-09 17:37:52.867+05:30	Special Report
455	2019-09-09 17:37:52.737+05:30	2019-09-09 17:37:52.737+05:30	Technology & Innovation
454	2019-09-09 17:37:52.545+05:30	2019-09-09 17:37:52.545+05:30	Focus
453	2019-09-09 17:37:52.431+05:30	2019-09-09 17:37:52.431+05:30	Shop Floor Sojourn
452	2019-09-09 17:37:52.291+05:30	2019-09-09 17:37:52.292+05:30	OEM
451	2019-09-09 17:37:52.08+05:30	2019-09-09 17:37:52.08+05:30	Globescan
450	2019-09-09 17:37:51.94+05:30	2019-09-09 17:37:51.94+05:30	Corporate
449	2019-09-09 17:37:51.804+05:30	2019-09-09 17:37:51.804+05:30	Allied Industries
448	2019-09-09 17:37:51.645+05:30	2019-09-09 17:37:51.645+05:30	Power Lists
447	2019-09-09 17:37:51.39+05:30	2019-09-09 17:37:51.39+05:30	Products and Services
446	2019-09-09 17:37:51.256+05:30	2019-09-09 17:37:51.256+05:30	Projects and Tenders
445	2019-09-09 17:37:51.091+05:30	2019-09-09 17:37:51.091+05:30	Tribute To Titans
444	2019-09-09 17:37:50.744+05:30	2019-09-09 17:37:50.744+05:30	Perspective
443	2019-09-09 17:37:50.573+05:30	2019-09-09 17:37:50.574+05:30	Promotion
442	2019-09-09 17:37:50.409+05:30	2019-09-09 17:37:50.409+05:30	Book
441	2019-09-09 17:37:50.063+05:30	2019-09-09 17:37:50.063+05:30	Culture
440	2019-09-09 17:37:49.96+05:30	2019-09-09 17:37:49.961+05:30	Cover Story
439	2019-09-09 17:37:49.893+05:30	2019-09-09 17:37:49.893+05:30	Lifestyle
438	2019-09-09 17:37:49.805+05:30	2019-09-09 17:37:49.805+05:30	International
437	2019-09-09 17:37:49.722+05:30	2019-09-09 17:37:49.722+05:30	Deal Street
436	2019-09-09 17:37:49.651+05:30	2019-09-09 17:37:49.651+05:30	Articles
435	2019-09-09 17:37:49.563+05:30	2019-09-09 17:37:49.563+05:30	Design
434	2019-09-09 17:37:49.491+05:30	2019-09-09 17:37:49.491+05:30	F&B
433	2019-09-09 17:37:49.404+05:30	2019-09-09 17:37:49.404+05:30	Products
432	2019-09-09 17:37:49.315+05:30	2019-09-09 17:37:49.315+05:30	Business
431	2019-09-09 17:37:49.189+05:30	2019-09-09 17:37:49.189+05:30	Sectors
430	2019-09-09 17:37:49.122+05:30	2019-09-09 17:37:49.122+05:30	Products & suppliers
429	2019-09-09 17:37:49.034+05:30	2019-09-09 17:37:49.034+05:30	First Serve
428	2019-09-09 17:37:48.967+05:30	2019-09-09 17:37:48.967+05:30	Blog
427	2019-09-09 17:37:48.872+05:30	2019-09-09 17:37:48.872+05:30	gurumantra
426	2019-09-09 17:37:48.584+05:30	2019-09-09 17:37:48.584+05:30	strategy
425	2019-09-09 17:37:48.515+05:30	2019-09-09 17:37:48.515+05:30	myth buster
424	2019-09-09 17:37:48.445+05:30	2019-09-09 17:37:48.445+05:30	interview
423	2019-09-09 17:37:48.378+05:30	2019-09-09 17:37:48.378+05:30	cover story
422	2019-09-09 17:37:48.311+05:30	2019-09-09 17:37:48.311+05:30	Rankings
421	2019-09-09 17:37:48.242+05:30	2019-09-09 17:37:48.242+05:30	OutSourcing
420	2019-09-09 17:37:47.956+05:30	2019-09-09 17:37:47.956+05:30	TSchool
419	2019-09-09 17:37:47.889+05:30	2019-09-09 17:37:47.889+05:30	Virtualization
418	2019-09-09 17:37:47.822+05:30	2019-09-09 17:37:47.822+05:30	DQTop20
417	2019-09-09 17:37:47.75+05:30	2019-09-09 17:37:47.75+05:30	Peripherals
416	2019-09-09 17:37:47.668+05:30	2019-09-09 17:37:47.668+05:30	DeepDives
415	2019-09-09 17:37:47.599+05:30	2019-09-09 17:37:47.599+05:30	Storage
414	2019-09-09 17:37:47.527+05:30	2019-09-09 17:37:47.527+05:30	Editors Blog
413	2019-09-09 17:37:47.457+05:30	2019-09-09 17:37:47.457+05:30	Industrial segments
412	2019-09-09 17:37:47.388+05:30	2019-09-09 17:37:47.388+05:30	CIO Handbook
411	2019-09-09 17:37:47.32+05:30	2019-09-09 17:37:47.32+05:30	Enterprise Hardware
410	2019-09-09 17:37:47.253+05:30	2019-09-09 17:37:47.253+05:30	Networking
409	2019-09-09 17:37:47.164+05:30	2019-09-09 17:37:47.164+05:30	Insights
408	2019-09-09 17:37:47.038+05:30	2019-09-09 17:37:47.038+05:30	Datacenter
407	2019-09-09 17:37:46.967+05:30	2019-09-09 17:37:46.967+05:30	Data center
406	2019-09-09 17:37:46.899+05:30	2019-09-09 17:37:46.899+05:30	columns
405	2019-09-09 17:37:46.812+05:30	2019-09-09 17:37:46.812+05:30	Security
404	2019-09-09 17:37:46.745+05:30	2019-09-09 17:37:46.745+05:30	Top Stories
403	2019-09-09 17:37:46.664+05:30	2019-09-09 17:37:46.664+05:30	Internet
402	2019-09-09 17:37:46.575+05:30	2019-09-09 17:37:46.575+05:30	Cloud
401	2019-09-09 17:37:46.489+05:30	2019-09-09 17:37:46.489+05:30	Software
400	2019-09-09 17:37:46.422+05:30	2019-09-09 17:37:46.422+05:30	Mobility
399	2019-09-09 17:37:46.354+05:30	2019-09-09 17:37:46.354+05:30	Annuals
398	2019-09-09 17:37:46.286+05:30	2019-09-09 17:37:46.286+05:30	Features
397	2019-09-09 17:37:46.219+05:30	2019-09-09 17:37:46.219+05:30	In Conversation
396	2019-09-09 17:37:46.152+05:30	2019-09-09 17:37:46.152+05:30	FGFI& FSF
395	2019-09-09 17:37:46.079+05:30	2019-09-09 17:37:46.079+05:30	Chairman's Message
394	2019-09-09 17:37:46.01+05:30	2019-09-09 17:37:46.01+05:30	Our Consultants
393	2019-09-09 17:37:45.943+05:30	2019-09-09 17:37:45.943+05:30	Visual Merchandising
392	2019-09-09 17:37:45.864+05:30	2019-09-09 17:37:45.864+05:30	IFF
391	2019-09-09 17:37:45.795+05:30	2019-09-09 17:37:45.795+05:30	PHOTO GALLERY
390	2019-09-09 17:37:45.715+05:30	2019-09-09 17:37:45.715+05:30	Sponsored
389	2019-09-09 17:37:45.629+05:30	2019-09-09 17:37:45.629+05:30	Food Service
388	2019-09-09 17:37:45.56+05:30	2019-09-09 17:37:45.561+05:30	CIO Special
387	2019-09-09 17:37:45.467+05:30	2019-09-09 17:37:45.467+05:30	Retail Employees
386	2019-09-09 17:37:45.391+05:30	2019-09-09 17:37:45.391+05:30	International News
385	2019-09-09 17:37:45.309+05:30	2019-09-09 17:37:45.309+05:30	Retail Hub
384	2019-09-09 17:37:45.23+05:30	2019-09-09 17:37:45.23+05:30	India Food Forum
383	2019-09-09 17:37:45.162+05:30	2019-09-09 17:37:45.162+05:30	Common
382	2019-09-09 17:37:45.048+05:30	2019-09-09 17:37:45.048+05:30	Shopping Centre
381	2019-09-09 17:37:44.957+05:30	2019-09-09 17:37:44.957+05:30	Progressive Grocer
380	2019-09-09 17:37:44.831+05:30	2019-09-09 17:37:44.831+05:30	Beauty & Wellness
379	2019-09-09 17:37:44.733+05:30	2019-09-09 17:37:44.733+05:30	Fashion
377	2019-09-09 17:37:44.542+05:30	2019-09-09 17:37:44.542+05:30	Past Events
376	2019-09-09 17:37:44.474+05:30	2019-09-09 17:37:44.474+05:30	Stories
375	2019-09-09 17:37:44.392+05:30	2019-09-09 17:37:44.392+05:30	Emerging Market
374	2019-09-09 17:37:44.31+05:30	2019-09-09 17:37:44.31+05:30	Ferro Alloy
373	2019-09-09 17:37:44.242+05:30	2019-09-09 17:37:44.242+05:30	Graphite Electrode
372	2019-09-09 17:37:44.172+05:30	2019-09-09 17:37:44.172+05:30	Recycling
371	2019-09-09 17:37:44.098+05:30	2019-09-09 17:37:44.098+05:30	Technology Next
370	2019-09-09 17:37:44.026+05:30	2019-09-09 17:37:44.026+05:30	Personality
369	2019-09-09 17:37:43.951+05:30	2019-09-09 17:37:43.951+05:30	Coal
368	2019-09-09 17:37:43.88+05:30	2019-09-09 17:37:43.88+05:30	Iron Ore
367	2019-09-09 17:37:43.749+05:30	2019-09-09 17:37:43.749+05:30	Steel
366	2019-09-09 17:37:43.67+05:30	2019-09-09 17:37:43.67+05:30	Polemicist
365	2019-09-09 17:37:43.594+05:30	2019-09-09 17:37:43.594+05:30	Ideas
364	2019-09-09 17:37:43.525+05:30	2019-09-09 17:37:43.525+05:30	Bystander
363	2019-09-09 17:37:43.454+05:30	2019-09-09 17:37:43.454+05:30	Bengaluru Buzz
362	2019-09-09 17:37:43.386+05:30	2019-09-09 17:37:43.386+05:30	Multimedia
361	2019-09-09 17:37:43.31+05:30	2019-09-09 17:37:43.31+05:30	Investing
360	2019-09-09 17:37:43.241+05:30	2019-09-09 17:37:43.241+05:30	Venture
359	2019-09-09 17:37:43.169+05:30	2019-09-09 17:37:43.169+05:30	Reviews
358	2019-09-09 17:37:43.101+05:30	2019-09-09 17:37:43.101+05:30	Enterprise
357	2019-09-09 17:37:43.012+05:30	2019-09-09 17:37:43.012+05:30	Macro
356	2019-09-09 17:37:42.942+05:30	2019-09-09 17:37:42.942+05:30	Featured
355	2019-09-09 17:37:42.87+05:30	2019-09-09 17:37:42.87+05:30	Looking East
354	2019-09-09 17:37:42.797+05:30	2019-09-09 17:37:42.797+05:30	Startups
353	2019-09-09 17:37:42.708+05:30	2019-09-09 17:37:42.708+05:30	Research
352	2019-09-09 17:37:42.642+05:30	2019-09-09 17:37:42.642+05:30	Education
351	2019-09-09 17:37:42.575+05:30	2019-09-09 17:37:42.575+05:30	News
350	2019-09-09 17:37:42.507+05:30	2019-09-09 17:37:42.507+05:30	Developers Corner
349	2019-09-09 17:37:42.428+05:30	2019-09-09 17:37:42.428+05:30	Opinions
348	2019-09-09 17:37:42.338+05:30	2019-09-09 17:37:42.338+05:30	Whispers
347	2019-09-09 17:37:42.269+05:30	2019-09-09 17:37:42.269+05:30	Budget
346	2019-09-09 17:37:42.202+05:30	2019-09-09 17:37:42.202+05:30	BEST OF INDIAN ECONOMY & MARKET
345	2019-09-09 17:37:42.133+05:30	2019-09-09 17:37:42.133+05:30	Travel
344	2019-09-09 17:37:42.066+05:30	2019-09-09 17:37:42.066+05:30	Latest News
343	2019-09-09 17:37:41.995+05:30	2019-09-09 17:37:41.995+05:30	Book Talk
342	2019-09-09 17:37:41.907+05:30	2019-09-09 17:37:41.907+05:30	Company Analysis
340	2019-09-09 17:37:41.773+05:30	2019-09-09 17:37:41.773+05:30	Life Mantras
339	2019-09-09 17:37:41.705+05:30	2019-09-09 17:37:41.705+05:30	Life
338	2019-09-09 17:37:41.634+05:30	2019-09-09 17:37:41.634+05:30	Interviews
337	2019-09-09 17:37:41.568+05:30	2019-09-09 17:37:41.568+05:30	By Invite
336	2019-09-09 17:37:41.5+05:30	2019-09-09 17:37:41.5+05:30	Startup
335	2019-09-09 17:37:41.423+05:30	2019-09-09 17:37:41.423+05:30	Mutual Funds
334	2019-09-09 17:37:41.336+05:30	2019-09-09 17:37:41.336+05:30	Markets
333	2019-09-09 17:37:41.268+05:30	2019-09-09 17:37:41.268+05:30	Straight Talk
332	2019-09-09 17:37:41.186+05:30	2019-09-09 17:37:41.186+05:30	Big Story
331	2019-09-09 17:37:41.113+05:30	2019-09-09 17:37:41.113+05:30	Trending
330	2019-09-09 17:37:41.045+05:30	2019-09-09 17:37:41.045+05:30	More
329	2019-09-09 17:37:40.977+05:30	2019-09-09 17:37:40.977+05:30	Luxury
328	2019-09-09 17:37:40.91+05:30	2019-09-09 17:37:40.91+05:30	Opinion
327	2019-09-09 17:37:40.842+05:30	2019-09-09 17:37:40.842+05:30	Web Exclusive
326	2019-09-09 17:37:40.774+05:30	2019-09-09 17:37:40.774+05:30	Video
325	2019-09-09 17:37:40.704+05:30	2019-09-09 17:37:40.704+05:30	Case Study
324	2019-09-09 17:37:40.636+05:30	2019-09-09 17:37:40.636+05:30	Energy & Infra
323	2019-09-09 17:37:40.572+05:30	2019-09-09 17:37:40.572+05:30	Banking & Finance
322	2019-09-09 17:37:40.506+05:30	2019-09-09 17:37:40.506+05:30	Healthcare
321	2019-09-09 17:37:40.439+05:30	2019-09-09 17:37:40.439+05:30	After Hours
320	2019-09-09 17:37:40.37+05:30	2019-09-09 17:37:40.37+05:30	Gadgets & Technology
319	2019-09-09 17:37:40.303+05:30	2019-09-09 17:37:40.303+05:30	Companies & Markets
318	2019-09-09 17:37:40.236+05:30	2019-09-09 17:37:40.236+05:30	Education And Career
317	2019-09-09 17:37:40.169+05:30	2019-09-09 17:37:40.169+05:30	T&E
316	2019-09-09 17:37:40.102+05:30	2019-09-09 17:37:40.102+05:30	Finance & Risk Management
315	2019-09-09 17:37:40.036+05:30	2019-09-09 17:37:40.036+05:30	The Deep Dive
314	2019-09-09 17:37:39.968+05:30	2019-09-09 17:37:39.968+05:30	Corporate Finance
313	2019-09-09 17:37:39.901+05:30	2019-09-09 17:37:39.901+05:30	Innovative CFO
312	2019-09-09 17:37:39.833+05:30	2019-09-09 17:37:39.833+05:30	Magazine
311	2019-09-09 17:37:39.765+05:30	2019-09-09 17:37:39.765+05:30	The Quiz
310	2019-09-09 17:37:39.694+05:30	2019-09-09 17:37:39.694+05:30	From the Editor
309	2019-09-09 17:37:39.629+05:30	2019-09-09 17:37:39.629+05:30	Business Outlook Survey
308	2019-09-09 17:37:39.564+05:30	2019-09-09 17:37:39.564+05:30	Buzz
307	2019-09-09 17:37:39.496+05:30	2019-09-09 17:37:39.496+05:30	Topline
306	2019-09-09 17:37:39.423+05:30	2019-09-09 17:37:39.423+05:30	Banking & Capital Markets
305	2019-09-09 17:37:39.35+05:30	2019-09-09 17:37:39.35+05:30	Human Capital Management
304	2019-09-09 17:37:39.283+05:30	2019-09-09 17:37:39.283+05:30	Recruiting
303	2019-09-09 17:37:39.213+05:30	2019-09-09 17:37:39.213+05:30	Talent Management
302	2019-09-09 17:37:39.145+05:30	2019-09-09 17:37:39.145+05:30	Employee Benefits and Compensation
301	2019-09-09 17:37:39.077+05:30	2019-09-09 17:37:39.077+05:30	Human Resources
300	2019-09-09 17:37:39.009+05:30	2019-09-09 17:37:39.009+05:30	Retirement Plans
299	2019-09-09 17:37:38.942+05:30	2019-09-09 17:37:38.942+05:30	Job Hunting
298	2019-09-09 17:37:38.87+05:30	2019-09-09 17:37:38.87+05:30	Workplace Issues
297	2019-09-09 17:37:38.801+05:30	2019-09-09 17:37:38.801+05:30	Hiring
296	2019-09-09 17:37:38.734+05:30	2019-09-09 17:37:38.734+05:30	Training
295	2019-09-09 17:37:38.667+05:30	2019-09-09 17:37:38.667+05:30	People
294	2019-09-09 17:37:38.601+05:30	2019-09-09 17:37:38.601+05:30	Health Benefits
293	2019-09-09 17:37:38.534+05:30	2019-09-09 17:37:38.534+05:30	Compensation
292	2019-09-09 17:37:38.467+05:30	2019-09-09 17:37:38.467+05:30	Business Software
291	2019-09-09 17:37:38.4+05:30	2019-09-09 17:37:38.4+05:30	CIO-CFO Partnership
290	2019-09-09 17:37:38.332+05:30	2019-09-09 17:37:38.332+05:30	Automation
289	2019-09-09 17:37:38.264+05:30	2019-09-09 17:37:38.264+05:30	Robotic Process Automation
288	2019-09-09 17:37:38.194+05:30	2019-09-09 17:37:38.194+05:30	IT Security
287	2019-09-09 17:37:38.127+05:30	2019-09-09 17:37:38.127+05:30	Enterprise Performance Management
286	2019-09-09 17:37:38.059+05:30	2019-09-09 17:37:38.059+05:30	Payments
285	2019-09-09 17:37:37.992+05:30	2019-09-09 17:37:37.992+05:30	Internet of Things
284	2019-09-09 17:37:37.925+05:30	2019-09-09 17:37:37.925+05:30	Big Data
283	2019-09-09 17:37:37.857+05:30	2019-09-09 17:37:37.857+05:30	Spreadsheets
282	2019-09-09 17:37:37.789+05:30	2019-09-09 17:37:37.789+05:30	Enterprise Resource Planning
281	2019-09-09 17:37:37.723+05:30	2019-09-09 17:37:37.723+05:30	ERP
280	2019-09-09 17:37:37.656+05:30	2019-09-09 17:37:37.656+05:30	The Cloud
279	2019-09-09 17:37:37.591+05:30	2019-09-09 17:37:37.591+05:30	Social Media
278	2019-09-09 17:37:37.524+05:30	2019-09-09 17:37:37.524+05:30	Analytics
277	2019-09-09 17:37:37.457+05:30	2019-09-09 17:37:37.457+05:30	Data Security
276	2019-09-09 17:37:37.388+05:30	2019-09-09 17:37:37.388+05:30	Cybersecurity
275	2019-09-09 17:37:37.32+05:30	2019-09-09 17:37:37.32+05:30	Mobile
274	2019-09-09 17:37:37.251+05:30	2019-09-09 17:37:37.252+05:30	IT
273	2019-09-09 17:37:37.183+05:30	2019-09-09 17:37:37.183+05:30	IT Value
272	2019-09-09 17:37:37.116+05:30	2019-09-09 17:37:37.116+05:30	Applications
271	2019-09-09 17:37:37.048+05:30	2019-09-09 17:37:37.048+05:30	Finance Technology
270	2019-09-09 17:37:36.981+05:30	2019-09-09 17:37:36.981+05:30	Health Care
269	2019-09-09 17:37:36.914+05:30	2019-09-09 17:37:36.914+05:30	Accounting Standards
268	2019-09-09 17:37:36.847+05:30	2019-09-09 17:37:36.847+05:30	Equipment Financing
267	2019-09-09 17:37:36.78+05:30	2019-09-09 17:37:36.78+05:30	Mergers & Acquisitions
266	2019-09-09 17:37:36.712+05:30	2019-09-09 17:37:36.712+05:30	Working Capital
265	2019-09-09 17:37:36.645+05:30	2019-09-09 17:37:36.645+05:30	Investment Banking
264	2019-09-09 17:37:36.579+05:30	2019-09-09 17:37:36.58+05:30	IPOs
263	2019-09-09 17:37:36.516+05:30	2019-09-09 17:37:36.516+05:30	Cash Management
262	2019-09-09 17:37:36.449+05:30	2019-09-09 17:37:36.449+05:30	Investor Relations
261	2019-09-09 17:37:36.381+05:30	2019-09-09 17:37:36.381+05:30	Credit
260	2019-09-09 17:37:36.314+05:30	2019-09-09 17:37:36.315+05:30	Capital Markets
259	2019-09-09 17:37:36.248+05:30	2019-09-09 17:37:36.248+05:30	Bankruptcy
258	2019-09-09 17:37:36.181+05:30	2019-09-09 17:37:36.181+05:30	M&A
257	2019-09-09 17:37:36.113+05:30	2019-09-09 17:37:36.113+05:30	Book Reviews
256	2019-09-09 17:37:36.039+05:30	2019-09-09 17:37:36.039+05:30	Corporate Real Estate
255	2019-09-09 17:37:35.97+05:30	2019-09-09 17:37:35.97+05:30	Turnarounds
254	2019-09-09 17:37:35.902+05:30	2019-09-09 17:37:35.902+05:30	Business Expansion
225	2019-09-09 17:37:33.643+05:30	2019-09-09 17:37:33.643+05:30	Risk Management
224	2019-09-09 17:37:33.575+05:30	2019-09-09 17:37:33.576+05:30	Legal
223	2019-09-09 17:37:33.51+05:30	2019-09-09 17:37:33.51+05:30	Regulation
222	2019-09-09 17:37:33.443+05:30	2019-09-09 17:37:33.443+05:30	Innovation
221	2019-09-09 17:37:33.372+05:30	2019-09-09 17:37:33.373+05:30	Staffing
220	2019-09-09 17:37:33.305+05:30	2019-09-09 17:37:33.305+05:30	Careers
219	2019-09-09 17:37:33.211+05:30	2019-09-09 17:37:33.212+05:30	Growth Strategies
218	2019-09-09 17:37:33.144+05:30	2019-09-09 17:37:33.145+05:30	Events
217	2019-09-09 17:37:33.076+05:30	2019-09-09 17:37:33.077+05:30	Risk
216	2019-09-09 17:37:33.005+05:30	2019-09-09 17:37:33.006+05:30	Tax
215	2019-09-09 17:37:32.937+05:30	2019-09-09 17:37:32.937+05:30	Treasury
214	2019-09-09 17:37:32.87+05:30	2019-09-09 17:37:32.87+05:30	Economy
213	2019-09-09 17:37:32.803+05:30	2019-09-09 17:37:32.803+05:30	Global Roundup
212	2019-09-09 17:37:32.735+05:30	2019-09-09 17:37:32.735+05:30	Interview
211	2019-09-09 17:37:32.668+05:30	2019-09-09 17:37:32.668+05:30	Profile
210	2019-09-09 17:37:32.6+05:30	2019-09-09 17:37:32.6+05:30	Gizmos
209	2019-09-09 17:37:32.534+05:30	2019-09-09 17:37:32.534+05:30	On Wheels
208	2019-09-09 17:37:32.47+05:30	2019-09-09 17:37:32.47+05:30	CFO Lounge
207	2019-09-09 17:37:32.4+05:30	2019-09-09 17:37:32.4+05:30	CFOSpeak
206	2019-09-09 17:37:32.326+05:30	2019-09-09 17:37:32.326+05:30	Leader's World
205	2019-09-09 17:37:32.256+05:30	2019-09-09 17:37:32.256+05:30	Knowledge Series
204	2019-09-09 17:37:32.188+05:30	2019-09-09 17:37:32.189+05:30	Legal Angle
203	2019-09-09 17:37:32.12+05:30	2019-09-09 17:37:32.12+05:30	Editor's Note
202	2019-09-09 17:37:32.051+05:30	2019-09-09 17:37:32.051+05:30	Cfo-video
201	2019-09-09 17:37:31.983+05:30	2019-09-09 17:37:31.984+05:30	OPINIONS
200	2019-09-09 17:37:31.915+05:30	2019-09-09 17:37:31.915+05:30	Leadership
199	2019-09-09 17:33:21.61+05:30	2019-09-09 17:33:21.61+05:30	India Retail
198	2019-09-09 17:33:21.546+05:30	2019-09-09 17:33:21.546+05:30	The Machinist
197	2019-09-09 17:33:21.483+05:30	2019-09-09 17:33:21.483+05:30	What HiFi
196	2019-09-09 17:33:21.419+05:30	2019-09-09 17:33:21.419+05:30	Manufacturing Today
195	2019-09-09 17:33:21.346+05:30	2019-09-09 17:33:21.346+05:30	Auto Components India
194	2019-09-09 17:33:21.281+05:30	2019-09-09 17:33:21.281+05:30	Steel 360
193	2019-09-09 17:33:21.217+05:30	2019-09-09 17:33:21.217+05:30	Diamond World
192	2019-09-09 17:33:21.152+05:30	2019-09-09 17:33:21.152+05:30	Transreporter
191	2019-09-09 17:33:21.088+05:30	2019-09-09 17:33:21.088+05:30	Fortune India
190	2019-09-09 17:33:21.021+05:30	2019-09-09 17:33:21.021+05:30	Data Quest India
189	2019-09-09 17:33:20.957+05:30	2019-09-09 17:33:20.957+05:30	Construction Work Online
188	2019-09-09 17:33:20.891+05:30	2019-09-09 17:33:20.891+05:30	Bio Spectrum India
187	2019-09-09 17:33:20.611+05:30	2019-09-09 17:33:20.612+05:30	Analytics India Magazine
186	2019-09-09 17:33:20.546+05:30	2019-09-09 17:33:20.546+05:30	Marwar India
185	2019-09-09 17:33:20.484+05:30	2019-09-09 17:33:20.484+05:30	Food And Hospitality
184	2019-09-09 17:33:20.418+05:30	2019-09-09 17:33:20.418+05:30	Indian Economy and Market
183	2019-09-09 17:33:20.354+05:30	2019-09-09 17:33:20.354+05:30	Legal Era Online
182	2019-09-09 17:33:20.29+05:30	2019-09-09 17:33:20.29+05:30	Hotelier India
181	2019-09-09 17:33:20.225+05:30	2019-09-09 17:33:20.225+05:30	Business World
180	2019-09-09 17:33:20.143+05:30	2019-09-09 17:33:20.143+05:30	Human Capital
179	2019-09-09 17:33:20.079+05:30	2019-09-09 17:33:20.079+05:30	Technology
178	2019-09-09 17:33:20.014+05:30	2019-09-09 17:33:20.014+05:30	Human Capital & Careers
177	2019-09-09 17:33:19.95+05:30	2019-09-09 17:33:19.95+05:30	Accounting
176	2019-09-09 17:33:19.885+05:30	2019-09-09 17:33:19.885+05:30	Credit & Capital
175	2019-09-09 17:33:19.821+05:30	2019-09-09 17:33:19.821+05:30	Strategy
174	2019-09-09 17:33:19.755+05:30	2019-09-09 17:33:19.755+05:30	Accounting & Tax
173	2019-09-09 17:33:19.691+05:30	2019-09-09 17:33:19.691+05:30	Budgeting & Planning
172	2019-09-09 17:33:19.625+05:30	2019-09-09 17:33:19.625+05:30	Risk & Compliance
171	2019-09-09 17:33:19.552+05:30	2019-09-09 17:33:19.552+05:30	Growth Companies
170	2019-09-09 17:31:50.055+05:30	2019-09-09 17:31:50.055+05:30	CFO India
161	2019-04-24 15:05:18.085+05:30	2019-05-30 16:56:21.455+05:30	Uncategorized
153	2019-03-28 13:29:36.817+05:30	2019-03-28 13:29:36.817+05:30	Regulators
163	2019-04-30 16:17:08.342+05:30	2019-04-30 16:17:08.342+05:30	Crypto Currencies
123	2019-03-28 13:04:04.889+05:30	2019-04-24 14:19:18.893+05:30	Uncategorised
137	2019-03-28 13:25:09.781+05:30	2019-03-28 13:25:09.781+05:30	Finance
141	2019-03-28 13:26:18.322+05:30	2019-04-24 14:54:42.861+05:30	Policy
142	2019-03-28 13:26:34.898+05:30	2019-03-28 13:26:34.898+05:30	US Economy
143	2019-03-28 13:26:49.617+05:30	2019-03-28 13:26:49.617+05:30	Global Economy
144	2019-03-28 13:27:05.528+05:30	2019-03-28 13:27:05.528+05:30	Housing Market
145	2019-03-28 13:27:22.272+05:30	2019-03-28 13:27:22.272+05:30	Interest Rate
146	2019-03-28 13:27:40.806+05:30	2019-04-24 14:55:10.091+05:30	Growth
147	2019-03-28 13:28:02.118+05:30	2019-03-28 13:28:02.118+05:30	Commodities
148	2019-03-28 13:28:16.301+05:30	2019-03-28 13:28:16.301+05:30	Inflation
140	2019-03-28 13:26:03.317+05:30	2019-03-28 13:26:03.317+05:30	Economics
150	2019-03-28 13:28:47.476+05:30	2019-03-28 13:28:47.476+05:30	Currencies
151	2019-03-28 13:29:03.995+05:30	2019-03-28 13:29:03.995+05:30	Companies
152	2019-03-28 13:29:18.586+05:30	2019-03-28 13:29:18.586+05:30	Consumer Affairs
154	2019-03-28 13:29:55.489+05:30	2019-03-28 13:29:55.489+05:30	Analysis
155	2019-03-28 13:30:12.032+05:30	2019-03-28 13:30:12.032+05:30	Mergers and Acquisitions
149	2019-03-28 13:28:32.505+05:30	2019-03-28 13:28:32.505+05:30	Misc
156	2019-03-28 13:30:30.063+05:30	2019-03-28 13:30:30.063+05:30	Trade Unions
132	2019-03-28 13:23:52.167+05:30	2019-03-28 13:23:52.167+05:30	Regional Updates
124	2019-03-28 13:21:31.491+05:30	2019-03-28 13:21:31.491+05:30	Sector Updates
133	2019-03-28 13:24:11.958+05:30	2019-03-28 13:24:11.958+05:30	US
128	2019-03-28 13:22:34.697+05:30	2019-03-28 13:22:34.697+05:30	Transport
127	2019-03-28 13:22:17.818+05:30	2019-04-24 13:30:03.616+05:30	Tech
126	2019-03-28 13:22:03.011+05:30	2019-04-24 14:23:43.48+05:30	Retail
138	2019-03-28 13:25:28.604+05:30	2019-04-24 14:06:19.196+05:30	Recession
139	2019-03-28 13:25:47.243+05:30	2019-03-28 13:25:47.243+05:30	Personal Finance
131	2019-03-28 13:23:31.463+05:30	2019-04-24 14:52:11.216+05:30	Manufacturing
136	2019-03-28 13:24:53.43+05:30	2019-03-28 13:24:53.43+05:30	Japan
130	2019-03-28 13:23:13.599+05:30	2019-04-24 14:52:26.516+05:30	Food & Drinks
129	2019-03-28 13:22:52.769+05:30	2019-04-24 14:23:54.53+05:30	Energy
134	2019-03-28 13:24:26.414+05:30	2019-03-28 13:24:26.414+05:30	China
125	2019-03-28 13:21:48.209+05:30	2019-03-28 13:21:48.209+05:30	Banking
135	2019-03-28 13:24:38.933+05:30	2019-03-28 13:24:38.934+05:30	Asia
\.


--
-- Data for Name: core_categoryassociation; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.core_categoryassociation (id, child_cat_id, parent_cat_id) FROM stdin;
61	169	132
60	168	149
59	167	149
58	166	149
57	165	124
56	164	137
55	162	124
54	160	132
53	159	137
52	158	137
51	133	132
50	134	132
49	136	132
48	138	137
47	139	137
46	141	140
45	142	140
44	143	140
43	144	140
42	145	140
41	146	140
40	147	140
39	148	140
38	150	149
37	151	149
36	152	149
35	153	149
34	154	149
33	155	149
32	156	132
31	135	132
8	131	124
7	130	124
6	129	124
5	157	124
4	128	124
3	127	124
2	126	124
1	125	124
\.


--
-- Data for Name: core_categorydefaultimage; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.core_categorydefaultimage (id, default_image_url, category_id) FROM stdin;
78	http://newscout.in/static/images/category/default/us/04.jpg	133
77	http://newscout.in/static/images/category/default/us/03.jpg	133
76	http://newscout.in/static/images/category/default/us/02.jpg	133
75	http://newscout.in/static/images/category/default/us/01.jpg	133
74	http://newscout.in/static/images/category/default/transport/04.jpg	128
73	http://newscout.in/static/images/category/default/transport/03.jpg	128
72	http://newscout.in/static/images/category/default/transport/02.jpg	128
71	http://newscout.in/static/images/category/default/transport/01.jpg	128
70	http://newscout.in/static/images/category/default/tech/05.jpg	127
69	http://newscout.in/static/images/category/default/tech/04.jpg	127
68	http://newscout.in/static/images/category/default/tech/03.jpg	127
67	http://newscout.in/static/images/category/default/tech/02.jpg	127
66	http://newscout.in/static/images/category/default/tech/01.jpg	127
65	http://newscout.in/static/images/category/default/retail/07.jpg	126
64	http://newscout.in/static/images/category/default/retail/06.jpg	126
63	http://newscout.in/static/images/category/default/retail/05.jpg	126
62	http://newscout.in/static/images/category/default/retail/04.jpg	126
61	http://newscout.in/static/images/category/default/retail/03.jpg	126
60	http://newscout.in/static/images/category/default/retail/02.jpg	126
59	http://newscout.in/static/images/category/default/retail/01.jpg	126
58	http://newscout.in/static/images/category/default/recession/03.jpg	138
57	http://newscout.in/static/images/category/default/recession/02.png	138
56	http://newscout.in/static/images/category/default/recession/01.jpg	138
55	http://newscout.in/static/images/category/default/personal_finance/04.jpg	139
54	http://newscout.in/static/images/category/default/personal_finance/03.jpg	139
53	http://newscout.in/static/images/category/default/personal_finance/02.jpg	139
52	http://newscout.in/static/images/category/default/personal_finance/01.jpg	139
51	http://newscout.in/static/images/category/default/manufacturing/06.jpg	131
50	http://newscout.in/static/images/category/default/manufacturing/05.jpg	131
49	http://newscout.in/static/images/category/default/manufacturing/04.jpg	131
48	http://newscout.in/static/images/category/default/manufacturing/03.jpg	131
47	http://newscout.in/static/images/category/default/manufacturing/02.jpg	131
46	http://newscout.in/static/images/category/default/manufacturing/01.jpg	131
45	http://newscout.in/static/images/category/default/japan/05.jpg	136
44	http://newscout.in/static/images/category/default/japan/04.jpg	136
43	http://newscout.in/static/images/category/default/japan/03.jpg	136
42	http://newscout.in/static/images/category/default/japan/02.jpg	136
41	http://newscout.in/static/images/category/default/japan/01.jpg	136
40	http://newscout.in/static/images/category/default/ipo/05.jpg	159
39	http://newscout.in/static/images/category/default/ipo/04.jpg	159
38	http://newscout.in/static/images/category/default/ipo/03.jpg	159
37	http://newscout.in/static/images/category/default/ipo/02.jpg	159
36	http://newscout.in/static/images/category/default/ipo/01.jpg	159
35	http://newscout.in/static/images/category/default/india/04.jpg	160
34	http://newscout.in/static/images/category/default/india/03.jpg	160
33	http://newscout.in/static/images/category/default/india/02.jpg	160
32	http://newscout.in/static/images/category/default/india/01.jpg	160
31	http://newscout.in/static/images/category/default/funding/03.jpg	158
30	http://newscout.in/static/images/category/default/funding/02.jpg	158
29	http://newscout.in/static/images/category/default/funding/01.jpg	158
28	http://newscout.in/static/images/category/default/food/09.jpg	130
27	http://newscout.in/static/images/category/default/food/08.jpg	130
26	http://newscout.in/static/images/category/default/food/07.jpg	130
25	http://newscout.in/static/images/category/default/food/06.jpg	130
24	http://newscout.in/static/images/category/default/food/05.jpg	130
23	http://newscout.in/static/images/category/default/food/04.jpg	130
22	http://newscout.in/static/images/category/default/food/03.jpg	130
21	http://newscout.in/static/images/category/default/food/02.jpg	130
20	http://newscout.in/static/images/category/default/food/01.jpg	130
19	http://newscout.in/static/images/category/default/energy/04.jpg	129
18	http://newscout.in/static/images/category/default/energy/03.jpg	129
17	http://newscout.in/static/images/category/default/energy/02.jpg	129
16	http://newscout.in/static/images/category/default/energy/01.jpg	129
15	http://newscout.in/static/images/category/default/crypto/05.jpg	163
14	http://newscout.in/static/images/category/default/crypto/04.jpg	163
13	http://newscout.in/static/images/category/default/crypto/03.jpg	163
12	http://newscout.in/static/images/category/default/crypto/02.jpg	163
11	http://newscout.in/static/images/category/default/crypto/01.jpg	163
10	http://newscout.in/static/images/category/default/china/03.jpg	134
9	http://newscout.in/static/images/category/default/china/02.jpg	134
8	http://newscout.in/static/images/category/default/china/01.png	134
7	http://newscout.in/static/images/category/default/banking/03.jpg	125
6	http://newscout.in/static/images/category/default/banking/02.jpg	125
5	http://newscout.in/static/images/category/default/banking/01.jpg	125
4	http://newscout.in/static/images/category/default/asia/04.jpg	135
3	http://newscout.in/static/images/category/default/asia/03.jpg	135
2	http://newscout.in/static/images/category/default/asia/02.jpg	135
1	http://newscout.in/static/images/category/default/asia/01.jpg	135
\.


--
-- Data for Name: core_comment; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.core_comment (id, created_at, modified_at, comment, article_id, reply_id, user_id) FROM stdin;
\.


--
-- Data for Name: core_dailydigest; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.core_dailydigest (id, created_at, modified_at, device_id, domain_id) FROM stdin;
\.


--
-- Data for Name: core_dailydigest_articles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.core_dailydigest_articles (id, dailydigest_id, article_id) FROM stdin;
\.


--
-- Data for Name: core_devices; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.core_devices (id, device_name, device_id, user_id) FROM stdin;
\.


--
-- Data for Name: core_domain; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.core_domain (id, created_at, modified_at, domain_name, domain_id, default_image) FROM stdin;
54	2020-01-05 02:53:29.501+05:30	2020-01-05 02:53:29.501+05:30	Economic and Political Weekly	epw	static/images/domain/default.png
53	2020-01-05 02:50:05.196+05:30	2020-01-05 02:50:05.196+05:30	Solar Quarter	solarquarter	static/images/domain/default.png
52	2020-01-05 02:16:08.306+05:30	2020-01-05 02:16:08.306+05:30	Licensing Corner	licensingcorner	static/images/domain/default.png
51	2020-01-05 01:51:06.551+05:30	2020-01-05 01:51:06.551+05:30	The Teenager Today	theteenagertoday	static/images/domain/default.png
50	2020-01-05 01:28:30.097+05:30	2020-01-05 01:28:30.097+05:30	Retail Jewellers India	rjindia	static/images/domain/default.png
49	2020-01-05 01:26:40.076+05:30	2020-01-05 01:26:40.076+05:30	Diabetes Health	diabeteshealth	static/images/domain/default.png
48	2020-01-05 00:38:04.017+05:30	2020-01-05 00:38:04.017+05:30	EPR Magazine	eprmag	static/images/domain/default.png
47	2020-01-03 23:19:42.926+05:30	2020-01-03 23:19:42.926+05:30	Crains Detroit	crainsdetroit	static/images/domain/default.png
46	2020-01-03 20:52:42.633+05:30	2020-01-03 20:52:42.633+05:30	Charlotte Magazine	charlottemag	static/images/domain/default.png
45	2020-01-03 20:29:46.33+05:30	2020-01-03 20:29:46.33+05:30	I 4 Business	i4business	static/images/domain/default.png
44	2020-01-03 20:24:34.337+05:30	2020-01-03 20:24:34.337+05:30	Tampa Bay Business and Wealth	tbbw	static/images/domain/default.png
43	2020-01-03 19:54:00.757+05:30	2020-01-03 19:54:00.757+05:30	Hawaii Business	hawaiibusiness	static/images/domain/default.png
42	2020-01-03 19:44:32.321+05:30	2020-01-03 19:44:32.321+05:30	Cuisine Oir Magazine	cuisinemag	static/images/domain/default.png
41	2020-01-03 19:41:53.154+05:30	2020-01-03 19:41:53.154+05:30	Community Magazine	communitymag	static/images/domain/default.png
40	2020-01-03 19:41:33.737+05:30	2020-01-03 19:41:33.737+05:30	Indian Business Journal	ibj	static/images/domain/default.png
39	2020-01-03 19:09:51.05+05:30	2020-01-03 19:09:51.05+05:30	Pets Plus Mag	petsplusmag	static/images/domain/default.png
38	2020-01-03 18:46:44.713+05:30	2020-01-03 18:46:44.713+05:30	Gigabit Magazine	gigabitmag	static/images/domain/default.png
37	2020-01-03 12:12:10.984+05:30	2020-01-03 12:12:10.984+05:30	QSR Magazine	qsrmagazine	static/images/domain/default.png
36	2020-01-02 15:53:52.035+05:30	2020-01-02 15:53:52.035+05:30	Tube Filter	tubefilter	static/images/domain/default.png
35	2020-01-02 13:24:00.58+05:30	2020-01-02 13:24:00.58+05:30	Best Supply Chain Practices	bestsupplychainpractices	static/images/domain/default.png
34	2019-09-30 10:17:27.455+05:30	2019-09-30 10:17:27.455+05:30	Construction World	constructionworld	static/images/domain/default.png
33	2019-09-24 10:04:20.793+05:30	2019-09-24 10:04:20.793+05:30	Print Week	printweek	static/images/domain/default.png
32	2019-09-23 13:01:57.671+05:30	2019-09-23 13:01:57.671+05:30	Business Goa	businessgoa	static/images/domain/default.png
31	2019-09-20 16:30:20.131+05:30	2019-09-20 16:30:20.131+05:30	Maritime Gateway	maritimegateway	static/images/domain/default.png
30	2019-09-20 12:56:08.544+05:30	2019-09-20 12:56:08.544+05:30	Tyre Asia	tyreasia	static/images/domain/default.png
29	2019-09-19 16:49:38.887+05:30	2019-09-19 16:49:38.887+05:30	Rubber Asia	rubberasia	static/images/domain/default.png
28	2019-09-19 12:15:56.799+05:30	2019-09-19 12:15:56.799+05:30	Motor India Online	motorindiaonline	static/images/domain/default.png
27	2019-09-19 11:48:16.472+05:30	2019-09-19 11:48:16.472+05:30	SME Channels	smechannels	static/images/domain/default.png
26	2019-09-18 18:30:51.115+05:30	2019-09-18 18:30:51.115+05:30	Startup 360	startup360	static/images/domain/default.png
25	2019-09-18 17:51:28.982+05:30	2019-09-18 17:51:28.982+05:30	Banking Frontiers	bankingfrontiers	static/images/domain/default.png
24	2019-09-14 12:32:54.872+05:30	2019-09-14 12:47:34.695+05:30	Auto CarPro	autocarpro	static/images/domain/default.png
23	2019-09-09 16:57:13.375+05:30	2019-09-09 16:57:13.375+05:30	What HiFi	hifi	static/images/domain/default.png
22	2019-09-09 16:57:13.288+05:30	2019-09-09 16:57:13.288+05:30	Diamond World	diamond	static/images/domain/default.png
21	2019-09-09 16:57:13.202+05:30	2019-09-09 16:57:13.202+05:30	Transreporter	transreporter	static/images/domain/default.png
20	2019-09-09 16:57:13.117+05:30	2019-09-09 16:57:13.117+05:30	Bio Spectrum India	biosindia	static/images/domain/default.png
19	2019-09-09 16:57:13.033+05:30	2019-09-09 16:57:13.033+05:30	Food And Hospitality	foodandhospitality	static/images/domain/default.png
18	2019-09-09 16:57:12.947+05:30	2019-09-09 16:57:12.947+05:30	The Machinist	machine	static/images/domain/default.png
17	2019-09-09 16:57:12.862+05:30	2019-09-09 16:57:12.862+05:30	Auto Components India	acindia	static/images/domain/default.png
16	2019-09-09 16:57:12.777+05:30	2019-09-09 16:57:12.777+05:30	Construction Work Online	cwonline	static/images/domain/default.png
15	2019-09-09 16:57:12.691+05:30	2019-09-09 16:57:12.691+05:30	Marwar India	marwarindia	static/images/domain/default.png
14	2019-09-09 16:57:12.606+05:30	2019-09-09 16:57:12.606+05:30	Legal Era Online	legaleraonline	static/images/domain/default.png
13	2019-09-09 16:57:12.522+05:30	2019-09-09 16:57:12.522+05:30	Hotelier India	hotelierindia	static/images/domain/default.png
12	2019-09-09 16:57:12.437+05:30	2019-09-09 16:57:12.437+05:30	Manufacturing Today	mitoday	static/images/domain/default.png
11	2019-09-09 16:57:12.352+05:30	2019-09-09 16:57:12.352+05:30	The Smart Manager	thesmartmanager	static/images/domain/default.png
10	2019-09-09 16:57:12.268+05:30	2019-09-09 16:57:12.268+05:30	Data Quest India	dqindia	static/images/domain/default.png
9	2019-09-09 16:57:12.182+05:30	2019-09-09 16:57:12.182+05:30	India Retailing	indiaretail	static/images/domain/default.png
8	2019-09-09 16:57:12.096+05:30	2019-09-09 16:57:12.096+05:30	Steel 360	steel360	static/images/domain/default.png
7	2019-09-09 16:57:12.01+05:30	2019-09-09 16:57:12.01+05:30	Fortune India	fortuneindia	static/images/domain/default.png
6	2019-09-09 16:57:11.877+05:30	2019-09-09 16:57:11.877+05:30	Analytics India Magazine	aim	static/images/domain/default.png
5	2019-09-09 16:57:11.79+05:30	2019-09-09 16:57:11.79+05:30	Indian Economy and Market	ieam	static/images/domain/default.png
4	2019-09-09 16:57:11.7+05:30	2019-09-09 16:57:11.7+05:30	Business World	businessworld	static/images/domain/default.png
3	2019-07-31 16:02:45.059+05:30	2019-09-09 16:57:11.582+05:30	CFO-USA	cfousa	static/images/domain/default.png
2	2019-09-09 16:57:13.458+05:30	2019-09-09 16:57:13.458+05:30	CFO-India	cfoindia	static/images/domain/default.png
1	2019-09-09 16:41:22.114+05:30	2019-09-09 16:41:22.114+05:30	NewsCout	newscout	static/images/domain/default.png
\.


--
-- Data for Name: core_draftmedia; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.core_draftmedia (id, created_at, modified_at, image) FROM stdin;
\.


--
-- Data for Name: core_hashtag; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.core_hashtag (id, name) FROM stdin;
2573	99
1004	propublica
1003	facebook advertising
1002	ethnic affinity targeting
1001	firefox
1000	browsers
999	animated gif
998	strava
997	silent pocket
996	faraday cage
995	legal tech
994	legal services
993	justin kan
992	general catalyst
991	atrium lts
990	onavo
989	search
988	ios keyboard
987	gboard
986	equity podcast
985	dropbox
984	bryan schreier
983	vpn
982	algo vpn
981	edward snowden
980	restoring internet freedom
979	mignon clyburn
978	windows phone 7
977	iphone
976	tax law
975	lawyer
974	european research council
973	distributed ledger
972	prism
971	lgbt
970	privacy international
969	european consumer organization
968	eff
967	ecj
966	nsa
965	warrantless surveillance
964	foreign intelligence surveillance act
963	google home mini
962	kurger bing
961	google home
960	burger king
959	first amendment
958	echo
957	amazon echo
956	server
955	safecoin
954	safe network
953	peer to peer
952	maidsafe
951	internet
950	alpha
949	storage
948	wwdc2016
947	wwdc
946	spotlight
945	smartphones
944	os x
943	mach
942	ios 9
941	ios
940	craig federighi
939	apple inc
938	online trackers
937	ghostery
936	grindr
935	trump administration
934	irish data protection authority
933	fundamental rights
932	sinclair
931	seattle
930	snap
929	definitely a camera company
928	camera company
927	sticker
926	mobile software
925	giphy
924	redesign
923	change.org
922	wtf is
921	isps
920	nextel
919	messageme
918	hyperhyper.com
917	kevin rose
916	gif
915	highlight
914	glancee
913	ambient location
912	facial recognition software
911	phhhoto
910	snapchat discover
909	snap map
908	taxi regulations
907	scl elections
906	facebook messenger day
905	ted ullyot
904	regulations
903	disrupt sf
902	disrupt
901	crowdsourcing
900	disrupt sf 2016
899	amp
898	sms
897	snap earnings
896	kevin systrom
895	facebook download your information
894	internet business models
893	scams
892	litecoin
891	ethereum
890	cryptocurrency
889	child safety
888	bbc
887	people trafficking
886	people smuggling
885	content moderation
884	linkedin
883	martin lewis
882	parents
881	parental control
880	family link
879	families
878	web developers
877	mozilla
876	censorshit
875	facebook lite
874	dow jones
872	slice
871	rakuten
870	brave software
869	adblocking
868	facial recognition
867	face recognition technology
866	social influence
865	lithium
864	ryan hoover
863	psychology
862	products
861	product hunt
860	josh elman
859	greylock partners
858	google i/o 2018
857	google i/o
856	subscription commerce
855	justfab
854	asi data science
853	tracking
852	path
851	netzdg
850	hate crime
849	freedom of speech
848	censorship
847	suicide
846	self harm
845	youtube kids
844	videos
843	video services
842	parent
841	kids
840	family
839	content
838	children
837	online radicalization
836	extremism
835	lithium technologies
834	klout
833	unroll.me
832	privacy policy
831	brendan eich
830	brave
829	bat
828	ad blocking
827	yandex
826	voxer
825	vine
824	facebook pages
823	bing
822	algorithmic feeds
821	telegram
820	radicalization
819	isis
818	online platforms
817	law enforcement
816	hate
815	germany
814	freedom of expression
813	crime
812	amber rudd
811	abuse
810	tcuk
809	personality test
808	cambridge university
807	spain
806	ad targeting
805	competition commission
804	dcms
803	botnets
802	trollfarms
801	electoral interference
800	washington
799	national security
798	human rights
797	ico
796	us government
795	section 702
794	ppd 28
793	fisa
792	eu us privacy shield
791	uk government
790	social media platforms
789	online content
788	social advertising
787	theresa may
786	election law
785	facts
784	climate science
783	climate change
782	snowden
781	schrems
780	european court of justice
779	ron wyden
778	voice imitation
777	lyrebird
776	pornography
775	pornhub
774	porn
773	involuntary porn
772	russian
771	political campaigning
770	search results
769	misinformation
768	privacy shield
767	elizabeth denham
766	peter thiel
765	marc andreessen
764	jan koum
763	commuting
762	david vladeck
761	palmer luckey
760	developers
759	apis
758	europe vs facebook
757	rt
756	propaganda
755	news media
754	clickbait
753	unilever
752	terrorism
751	online extremism
750	online advertising
749	click fraud
748	ad fraud
747	web tracking
746	data controller
745	cookies
744	consent
743	norwegian consumer council
742	data breach
741	center for digital democracy
740	mass surveillance
739	europe v facebook
738	class action
737	cjeu
736	app permissions
735	zuckerber testimony
734	troll
733	texas
732	oculus
731	founders fund
730	safe harbor
729	cnil
728	data sharing
727	facebook audience network
726	digital advertising
725	andrew bosworth
724	tracker blocker
723	tracker
722	filter bubble
721	encryption
720	duckduckgo
719	do not track
718	browser extension
717	anti tracking
716	targeted advertising
715	ireland
714	belgium
713	austria
712	data harvesting
711	data mining
710	new zealand
709	john edwards
708	deletefacebook
707	wit.ai
706	natural language processing
705	chatbot
704	bots
703	cloud
702	translation
701	facebook translation
700	facebook artificial intelligence
699	reggie brown
698	how to turn down a billion dollars
697	evan spiegel
696	billy gallagher
695	snapchat stories
694	the guardian
693	federal trade commission
692	chris wylie
691	aleksandr kogan
690	aggregateiq
689	snapchat redesign
688	snap inc
687	streaming media
686	multimedia
685	cryptocurrencies
684	dark pattern design
683	business ethics
682	ad tech
681	dcms committee
680	damian collins
679	claude moraes
678	brussels
677	social networking
676	max schrems
675	lawsuit
674	surveillance
673	paul olivier dehaye
672	data protection law
671	visual communication
670	reese witherspoon
669	kristen wiig
668	writer
667	steven spielberg
666	science fiction
665	glass
664	fiction
663	battlestar
662	amazing stories
661	documentary
660	kevin durant
659	tv app
658	damien chazelle
657	disinformation
656	messaging
655	transport for london
654	transport
653	tfl
652	facebook q1 2018
651	cordcutters
650	whatsapp for business
649	f8 2018
648	uber drivers
647	workers rights
646	sharing economy
645	gig economy
644	courier
643	hack
642	ajit pai
641	television in the united states
640	jennifer aniston
639	genealogy
638	cnn
637	sports streaming
636	espns plus
635	tv shows
634	apple tv
633	ronald d moore
632	original content
631	battlestar galactica
630	phoenix
629	norway
628	fuel cell
627	facebook policy
626	colin stretch
625	acquisition
624	department of justice
623	antitrust
622	whatsapp status
621	stories
620	messenger day
619	instagram stories
618	ride hailing
617	car sharing
616	net neutrality vote
615	fcc
614	ces2016
613	espn streaming service
612	bamtech
611	cord cutting
610	foundation
609	collaborative consumption
608	syngenta
607	agrocenta
606	snapchat clone
605	online sales
604	marketing
603	konga
602	internet advertising
601	black friday
600	salesforce
599	jumia
598	farmcrowdy
597	delivery hero
596	brck
595	bono
594	bill mcglashan
593	alex stamos
592	personal data
591	election
590	adtech
589	espn
588	sports
587	television
586	streaming video
585	streaming tv
584	streaming music
583	music
582	hulu
581	21st century fox
580	the walt disney company
579	fox
578	m kopa
577	gray ghost ventures
576	electricity
575	greentech
574	facebook stories
573	facebook earnings q3 2018
572	supply chain
571	online retail
570	financial services
569	fast moving consumer goods
568	consumer products
567	food
566	facebook data
565	facebook platform
564	facebook data privacy
563	ibm
562	hello tractor
561	agtech
560	blockchain
559	softbank
558	pepsi
557	online shopping
556	morocco
555	metal slug
554	latin america
553	kinnevik
552	harvard
551	entrepreneur
550	egypt
549	dara khosrowshahi
548	board member
547	verizon
546	time warner
545	nbcuniversal
544	hbo
543	cell phones
541	fine
540	exxon
539	zuckerberg testimony
538	ride sharing
537	lyft
536	thumbs up
535	rating
534	five star rating
533	data privacy
532	the social network
531	poland
530	messenger
529	krakow
528	aqua teen hunger force
527	study
526	manipulation
525	army
524	ftc
523	streaming services
522	recommendations
521	personalization
520	netflix originals
519	netflix original programming
518	discrimination
517	advertising
516	diversity
515	ads
514	blockchains
513	bitcoin
512	right to be forgotten
511	privacy by design
510	personally identifiable information
509	data portability
508	data minimization
507	data breaches
506	automated decisions
505	trump
504	net neutrality
503	internet.org
502	sheryl sandberg
501	hate speech
499	general data protection regulation
498	gdpr
497	data security
496	data protection
495	terms of service
494	facebookwhatsapp
493	disney
492	comcast
491	facebook election interference
490	trailers
489	streaming service
488	promos
487	previews
486	facebook custom audiences
485	facebook ads
484	zuckerberg
483	political advertising
482	chris cox
481	emerging markets
480	regulation
479	internet research agency
478	facebook fake news
477	senate intelligence committee
476	streaming
475	ott
474	netflix everywhere
473	media streaming
472	cyberagent ventures
471	sony
470	snapchat
469	mike schroepfer
468	video on demand
467	bskyb
466	walker
465	university of cambridge
464	ted cruz
463	president
462	prediction
461	journalist
460	data management
459	big data
458	alexander nix
457	nasdaq
456	talent
455	drama
454	u.s. senate
453	techcrunch startup battlefield africa 2018
452	startup battlefield disrupt sf 2018
451	startup battlefield
450	disrupt sf 2018
449	disrupt san francisco 2018
448	events
447	reed hastings
446	viddsee
445	tiktok
444	next 10 ventures
443	benjamin grubbs
442	workflow
441	scanning
440	robotics process automation
439	abbyy
438	time well spent
437	facebook earnings
436	developer
435	senate
434	facebook privacy
433	paradise papers
432	jersey
431	fb
430	cambridge analytica
429	rex tillerson
428	bangladesh
427	eu
426	digital business
425	brexit
424	russian election interference
423	russia
422	politics
421	honest ads act
420	elections
419	democrats
418	2016 election
417	privacy
416	double irish
415	zipline
414	world economic forum
413	wireless
412	white house
411	ups
410	uavs
409	u.s. department of transportation
408	rocketmine
407	robotics
406	north carolina
405	mining
404	mexico
403	keenan wyrobek
402	jd.com
401	information technology
400	emerging technologies
399	embedded systems
398	drone
397	commercial drone alliance
396	co founder
395	civil aviation authority
394	california
393	benin
392	music industry
391	mest
390	lluminium greenhouses
389	kuunda 3d
388	essips international
387	afrostream
386	taxify
385	africas talking
384	tanzania
383	sky
382	pay tv
381	middle east
380	malaysia
379	liberty global
378	iflix
377	hooq
376	catcha group
375	broadband
374	western union
373	wechat
372	tencent
371	techstars
370	north america
369	mobile payments
368	london
367	internet access
366	electronics
365	coo
364	china
363	barclays
362	nuance
361	kofax
360	automation
359	viral video
358	video
357	logan paul
356	exits
355	mark zuckerberg
354	tax noncompliance
353	france
352	fisc
351	united nations
350	thailand
349	sri lanka
348	southeast asia
347	singapore
346	photo sharing
345	fake news
344	digital media
343	tax
342	margrethe vestager
341	founders factory
340	vaporizer
339	ecig
338	vape
337	pax labs
336	startup battlefield africa 2018
335	omobola johnson
334	lexi novitske
333	lagos
332	battlefield
331	nikola motor
330	social networks
329	social network
328	smartphone
327	safaricom
326	paypal
325	mobile technology
324	itunes
323	digital tv
322	uipath
321	rpa
320	robotic process automation
319	theskimm
318	virtual reality
317	venture capital investment
316	software
315	new york
314	los angeles
313	donald trump
312	david tisch
311	avatar
310	the new york times
309	scribd
308	ulysses
307	subscription service
306	moviepass
305	bloomberg
304	unicorns
303	bootstrapping
302	startup era
301	entrepreneurs
300	alphabet
299	earnings
298	taxes
297	france newsletter
296	myanmar
295	asia
294	volvo
293	toyota
292	tokyo
291	subscription services
290	mobility services
289	lexus
288	kinto
287	japan
286	automotive industry
285	automotive
284	techcrunch disrupt
283	tcdisrupt
282	twitter
281	fda
280	trace
279	rise fund
278	rensource
277	liquid telecom
276	kudobuzz
275	european investment bank
274	nayeem islam
273	deep learning
272	blue hexagon
271	benchmark
270	altimeter
269	security
268	vodafone
267	online payments
266	mastercard
265	m pesa
264	greycroft
263	payments
262	servicetitan
261	home services
260	contractors
259	spark capital
258	software engineering
257	rwanda
256	computing
255	chan zuckerberg initiative
254	2018 year in review
253	united kingdom
252	presidential election
251	philippines
250	israel
249	indonesia
248	general election
247	european parliament
246	european commission
245	election security
244	election interference
243	ec
242	brazil
241	australia
240	advertising tech
239	triplebyte
238	indeed
237	glassdoor
236	two sigma ventures
235	spell
234	nvidia
233	microsoft azure
232	aws
231	ai
230	enterprise
229	greg reichow
228	upside partnership
227	vice media
226	sequoia capital
225	pinterest
224	insurance
223	fertilityiq
222	fertility
221	analog devices
220	metoo
219	facebook messenger
218	daily crunch
217	exchange commission
216	goldman sachs
215	first round capital
214	stockx
213	stadium goods
212	kith
211	grailed
210	flight club
209	accel
208	vaporizers
207	nicotine
206	social
205	policy
204	opinion
203	gadgets
202	juul labs
201	machine learning
200	talia goldberg
199	zimbabwe
198	world wide web
197	vp
196	visa
195	ukraine
194	uganda
193	tpg growth
192	technology
191	techcrunch
190	spokesperson
189	south africa
188	rave
187	nigeria
186	naspers
185	nairobi
184	mobile payment
183	microsoft
182	maryland
181	kenya
180	india
179	ghana
178	generation investment management
177	flutterwave
176	european union
175	ethiopia
174	econet wireless
173	east africa
172	e commerce
171	credit cards
170	congress
169	ceo
168	cellulant
167	cameroon
166	andela
165	al gore
164	africa
163	substack
162	podcasts
161	ticketing
160	gametime
159	brad griffith
158	mobile
157	eclipse ventures
156	sherpa capital
155	py
154	opendoor
153	lever
152	hired
151	dorm room fund
150	comcast ventures
149	hiring
148	education
147	propel venture partners
146	pentech ventures
145	mailchimp
144	datasine
143	content marketing
142	bnp paribas
141	monica  andy
140	interior define
139	uber freight
138	turvo
137	travis kalanick
136	slow ventures
135	reid hoffman
134	lior ron
133	felicis ventures
132	cargo
131	activant capital
130	logistics
129	project a ventures
128	dixa
127	europe
126	fred reid
125	brian chesky
124	airbnb
123	sneakers
122	retail
121	online marketplace
120	netflix
119	goat
118	footwear
117	eddy lu
116	wearables
115	san francisco
114	new york city
113	infertility
112	ebay
111	dadi
110	chief executive officer
109	buzzfeed
108	whatsapp
107	venture debt
106	united states
105	unicorn
104	startup company
103	sequoia
102	scott belsky
101	private equity
100	money
99	acquisitions
98	instagram
97	finance
96	executive
95	entrepreneurship
94	economy
93	customer acquisition cost
92	craigslist
91	behance
90	column
89	trackr
88	tile
87	lost item tracker
86	bluetooth tracker
85	adero
84	personnel
83	hardware
82	shopping
81	resale
80	rebag
79	marketplace
78	luxury
77	handbags
76	recent funding
75	ecommerce
74	ikea
73	grokstyle
72	facebook
71	computer vision
69	exit
68	augmented reality
67	virginia
66	tobacco
65	social media
64	head
63	drug administration
62	electronic cigarettes
61	e cigarettes
60	america
59	altria
58	government
57	y combinator
56	web summit
55	upfront ventures
54	uber
53	steve huffman
52	sanjay jha
51	reddit
50	mike mcnamara
49	megan rose dickey
48	mark suster
47	lime
46	josh constine
45	instacart
44	gimlet media
43	gimlet
42	fusion fund
41	crunchbase
40	consumer reports
39	bessemer venture partners
38	anchor
37	alex wilhelm
36	venture capital
35	tc
34	startups
32	funding
31	media
30	success
29	investing
28	apple
27	featured videos
26	environment
25	nasa
24	space
23	juul
22	amazon
21	business
20	chrome
19	google
18	gaming
17	spotify
16	film
15	tv
14	entertainment
13	youtube
12	artificial intelligence
11	photography
10	cybersecurity
9	transportation
8	world
7	law
6	android
5	apps
4	health
3	energy
2	tech
1	science
\.


--
-- Data for Name: core_menu; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.core_menu (id, domain_id, name_id, icon) FROM stdin;
\.


--
-- Data for Name: core_menu_submenu; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.core_menu_submenu (id, menu_id, submenu_id) FROM stdin;
\.


--
-- Data for Name: core_notification; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.core_notification (id, breaking_news, daily_edition, personalized, device_id) FROM stdin;
\.


--
-- Data for Name: core_relatedarticle; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.core_relatedarticle (id, created_at, modified_at, score, related_id, source_id) FROM stdin;
\.


--
-- Data for Name: core_scouteditem; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.core_scouteditem (id, title, url, category_id) FROM stdin;
\.


--
-- Data for Name: core_scoutfrontier; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.core_scoutfrontier (id, url, category_id) FROM stdin;
\.


--
-- Data for Name: core_socialaccount; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.core_socialaccount (id, provider, social_account_id, image_url, user_id) FROM stdin;
\.


--
-- Data for Name: core_source; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.core_source (id, name, url, active) FROM stdin;
114	epw.in	\N	f
113	solarquarter.com	\N	f
112	licensingcorner.com	\N	f
111	theteenagertoday.com	\N	f
110	retailjewellerindia.com	\N	f
109	diabeteshealth.co.in	\N	f
108	eprmagazine.com	\N	f
107	crainsdetroit.com	\N	f
106	charlottemagazine.com	\N	f
105	i4biz.com	\N	f
104	tbbwmag.com	\N	f
103	hawaiibusiness.com	\N	f
102	cuisinenoirmag.com	\N	f
101	communityrecmag.com	\N	f
100	indiabusinessjournalonline.com	\N	f
99	petsplusmag.com	\N	f
98	gigabitmagazine.com	\N	f
97	qsrmagazine.com	\N	f
96	tubefilter.com	\N	f
95	bestsupplychainpractices.com	\N	f
94	constructionworld.in	\N	f
93	printweek.in	\N	f
92	businessgoa.in	\N	f
91	maritimegateway.com	\N	f
90	tyre-asia.com	\N	f
89	rubberasia.com	\N	f
88	motorindiaonline.in	\N	f
87	smechannels.com	\N	f
86	startup360.news	\N	f
85	bankingfrontiers.com	\N	f
84	autocarpro.in	\N	f
83	whathifi.com	\N	f
82	diamondworld.net	\N	f
81	transreporter.com	\N	f
80	biospectrumindia.com	\N	f
79	foodhospitality.in	\N	f
78	themachinist.in	\N	f
77	autocomponentsindia.com	\N	f
76	constructionweekonline.com	\N	f
75	marwar.com	\N	f
74	legaleraonline.com	\N	f
73	hotelier.com	\N	f
72	manufacturingtodayindia.com	\N	f
71	thesmartmanager.com	\N	f
70	dqindia.com	\N	f
69	indiaretailing.com	\N	f
68	steel-360.com	\N	f
67	analyticsindiamag.com	\N	f
66	indianeconomyandmarket.com	\N	f
65	businessworld.in	\N	f
64	cfo.com	\N	f
63	cfo-india.in	\N	f
62	manufacturingglobal.com	\N	f
61	industryweek.com	\N	f
60	straitstimes.com	\N	f
59	businesstimes.com.sg	\N	f
58	coindesk.com	\N	f
57	cointelegraph.com	\N	f
56	moneycontrol.com	\N	f
55	washingtonpost.com	\N	f
54	newindianexpress.com	\N	f
53	japantimes.co.jp	\N	f
52	thehindubusinessline.com	\N	f
51	huffpost.com	\N	f
50	financialexpress.com	\N	f
49	livemint.com	\N	f
48	economictimes.indiatimes.com	\N	f
47	business-standard.com	\N	f
46		\N	f
45	thenation.com	https://www.thenation.com	f
44	scmp.com	https://www.scmp.com	f
43	zerohedge.com	https://www.zerohedge.com	f
42	torontolife.com	https://torontolife.com	t
41	huffingtonpost.in	\N	f
40	newsmax.com	\N	f
39	washington.cbslocal.com	\N	f
38	tampa.cbslocal.com	\N	f
37	losangeles.cbslocal.com	\N	f
36	miamiherald.com	\N	f
35	boston.com	\N	f
34	boston.cbslocal.com	\N	f
33	nbcnews.com	\N	f
32	nypost.com	\N	f
31	us.cnn.com	\N	f
30	dfw.cbslocal.com	\N	f
29	abcnews.go.com	\N	f
28	cbsnews.com	\N	f
27	mercurynews.com	\N	f
26	denverpost.com	\N	f
25	latimes.com	\N	f
24	foxnews.com	\N	f
23	breitbart.com	\N	f
22	newyork.cbslocal.com	\N	f
21	reuters.com	\N	f
20	newsweek.com	\N	f
19	sanfrancisco.cbslocal.com	\N	f
18	politico.com	\N	f
17	seattletimes.com	\N	f
16	washingtontimes.com	\N	f
15	observer.com	\N	f
14	stltoday.com	\N	f
13	usatoday.com	\N	f
12	npr.org	\N	f
11	nydailynews.com	\N	f
10	chicagotribune.com	\N	f
9	bloomberg.com	\N	f
8	bbc.com	\N	f
7	theguardian.com	\N	f
6	theregister.co.uk	\N	f
5	nytimes.com	\N	f
4	fastcompany.com	\N	f
3	techcrunch.com	\N	f
2	edition.cnn.com	\N	f
1	theverge.com	\N	f
\.


--
-- Data for Name: core_submenu; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.core_submenu (id, name_id, icon) FROM stdin;
\.


--
-- Data for Name: core_submenu_hash_tags; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.core_submenu_hash_tags (id, submenu_id, hashtag_id) FROM stdin;
\.


--
-- Data for Name: core_trendingarticle; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.core_trendingarticle (id, created_at, modified_at, active, score, domain_id) FROM stdin;
\.


--
-- Data for Name: core_trendingarticle_articles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.core_trendingarticle_articles (id, trendingarticle_id, article_id) FROM stdin;
\.


--
-- Data for Name: core_trendinghashtag; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.core_trendinghashtag (id, name) FROM stdin;
\.


--
-- Data for Name: django_admin_log; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.django_admin_log (id, action_time, object_id, object_repr, action_flag, change_message, content_type_id, user_id) FROM stdin;
1	2020-03-18 11:21:05.507242+05:30	1	Campaign object (1)	1	[{"added": {}}]	33	1
2	2020-03-18 11:24:08.82159+05:30	1	Campaign object (1)	2	[]	33	1
3	2020-03-18 12:33:17.271722+05:30	1	admin	2	[{"changed": {"fields": ["domain"]}}]	6	1
4	2020-03-18 14:32:25.154472+05:30	1	AdType object (1)	1	[{"added": {}}]	32	1
5	2020-03-18 14:32:29.331926+05:30	2	AdType object (2)	1	[{"added": {}}]	32	1
\.


--
-- Data for Name: django_content_type; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.django_content_type (id, app_label, model) FROM stdin;
1	admin	logentry
2	auth	permission
3	auth	group
4	contenttypes	contenttype
5	sessions	session
6	core	baseuserprofile
7	core	article
8	core	category
9	core	devices
10	core	domain
11	core	hashtag
12	core	source
13	core	trendinghashtag
14	core	trendingarticle
15	core	submenu
16	core	socialaccount
17	core	scoutfrontier
18	core	scouteditem
19	core	relatedarticle
20	core	notification
21	core	menu
22	core	dailydigest
23	core	categorydefaultimage
24	core	categoryassociation
25	core	bookmarkarticle
26	core	artilclelike
27	core	articlerating
28	core	articlemedia
29	core	draftmedia
30	authtoken	token
31	advertising	adgroup
32	advertising	adtype
33	advertising	campaign
34	advertising	advertisement
35	core	comment
36	captcha	captchastore
\.


--
-- Data for Name: django_migrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.django_migrations (id, app, name, applied) FROM stdin;
\.


--
-- Data for Name: django_session; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.django_session (session_key, session_data, expire_date) FROM stdin;
46bnm07nz2vprrjfqq7vcqgukp959s12	ZDNlZDI0NDdiOTBkMTFiZWNhNTQxZDJhMjNkNjBiYTY0YjQ3NWM3ODp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiY29yZS5iYWNrZW5kcy5FbWFpbE1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaGFzaCI6ImZiYWM0YmZhOWY4MThhYmIxZmUxOGIxMmJhN2VmYzk3ZDllZWIzNzIifQ==	2020-03-31 18:38:16.819873+05:30
\.


--
-- Name: advertising_adgroup_category_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.advertising_adgroup_category_id_seq', 1, true);


--
-- Name: advertising_adgroup_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.advertising_adgroup_id_seq', 1, true);


--
-- Name: advertising_adtype_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.advertising_adtype_id_seq', 2, true);


--
-- Name: advertising_advertisement_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.advertising_advertisement_id_seq', 3, true);


--
-- Name: advertising_campaign_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.advertising_campaign_id_seq', 2, true);


--
-- Name: auth_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.auth_group_id_seq', 1, false);


--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.auth_group_permissions_id_seq', 1, false);


--
-- Name: auth_permission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.auth_permission_id_seq', 1, false);


--
-- Name: captcha_captchastore_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.captcha_captchastore_id_seq', 1, false);


--
-- Name: core_article_hash_tags_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.core_article_hash_tags_id_seq', 456, true);


--
-- Name: core_article_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.core_article_id_seq', 1, false);


--
-- Name: core_articlemedia_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.core_articlemedia_id_seq', 1, false);


--
-- Name: core_articlerating_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.core_articlerating_id_seq', 1, false);


--
-- Name: core_artilclelike_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.core_artilclelike_id_seq', 1, false);


--
-- Name: core_baseuserprofile_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.core_baseuserprofile_groups_id_seq', 1, false);


--
-- Name: core_baseuserprofile_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.core_baseuserprofile_id_seq', 1, true);


--
-- Name: core_baseuserprofile_passion_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.core_baseuserprofile_passion_id_seq', 21, true);


--
-- Name: core_baseuserprofile_user_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.core_baseuserprofile_user_permissions_id_seq', 21, true);


--
-- Name: core_bookmarkarticle_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.core_bookmarkarticle_id_seq', 1, false);


--
-- Name: core_category_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.core_category_id_seq', 729, true);


--
-- Name: core_categoryassociation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.core_categoryassociation_id_seq', 61, true);


--
-- Name: core_categorydefaultimage_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.core_categorydefaultimage_id_seq', 78, true);


--
-- Name: core_comment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.core_comment_id_seq', 1, false);


--
-- Name: core_dailydigest_articles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.core_dailydigest_articles_id_seq', 2376, true);


--
-- Name: core_dailydigest_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.core_dailydigest_id_seq', 1, false);


--
-- Name: core_devices_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.core_devices_id_seq', 1, false);


--
-- Name: core_domain_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.core_domain_id_seq', 54, true);


--
-- Name: core_draftmedia_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.core_draftmedia_id_seq', 1, false);


--
-- Name: core_hashtag_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.core_hashtag_id_seq', 2573, true);


--
-- Name: core_menu_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.core_menu_id_seq', 1, false);


--
-- Name: core_menu_submenu_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.core_menu_submenu_id_seq', 796, true);


--
-- Name: core_notification_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.core_notification_id_seq', 1, false);


--
-- Name: core_relatedarticle_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.core_relatedarticle_id_seq', 1, false);


--
-- Name: core_scouteditem_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.core_scouteditem_id_seq', 1, false);


--
-- Name: core_scoutfrontier_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.core_scoutfrontier_id_seq', 1, false);


--
-- Name: core_socialaccount_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.core_socialaccount_id_seq', 1, false);


--
-- Name: core_source_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.core_source_id_seq', 114, true);


--
-- Name: core_submenu_hash_tags_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.core_submenu_hash_tags_id_seq', 40, true);


--
-- Name: core_submenu_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.core_submenu_id_seq', 1, false);


--
-- Name: core_trendingarticle_articles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.core_trendingarticle_articles_id_seq', 156, true);


--
-- Name: core_trendingarticle_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.core_trendingarticle_id_seq', 1, false);


--
-- Name: core_trendinghashtag_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.core_trendinghashtag_id_seq', 1, false);


--
-- Name: django_admin_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.django_admin_log_id_seq', 5, true);


--
-- Name: django_content_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.django_content_type_id_seq', 36, true);


--
-- Name: django_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.django_migrations_id_seq', 1, false);


--
-- Name: advertising_adgroup_category advertising_adgroup_cate_adgroup_id_category_id_c1175308_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.advertising_adgroup_category
    ADD CONSTRAINT advertising_adgroup_cate_adgroup_id_category_id_c1175308_uniq UNIQUE (adgroup_id, category_id);


--
-- Name: advertising_adgroup_category advertising_adgroup_category_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.advertising_adgroup_category
    ADD CONSTRAINT advertising_adgroup_category_pkey PRIMARY KEY (id);


--
-- Name: advertising_adgroup advertising_adgroup_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.advertising_adgroup
    ADD CONSTRAINT advertising_adgroup_pkey PRIMARY KEY (id);


--
-- Name: advertising_adtype advertising_adtype_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.advertising_adtype
    ADD CONSTRAINT advertising_adtype_pkey PRIMARY KEY (id);


--
-- Name: advertising_advertisement advertising_advertisement_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.advertising_advertisement
    ADD CONSTRAINT advertising_advertisement_pkey PRIMARY KEY (id);


--
-- Name: advertising_campaign advertising_campaign_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.advertising_campaign
    ADD CONSTRAINT advertising_campaign_pkey PRIMARY KEY (id);


--
-- Name: auth_group auth_group_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_name_key UNIQUE (name);


--
-- Name: auth_group_permissions auth_group_permissions_group_id_permission_id_0cd325b0_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_permission_id_0cd325b0_uniq UNIQUE (group_id, permission_id);


--
-- Name: auth_group_permissions auth_group_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_group auth_group_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_pkey PRIMARY KEY (id);


--
-- Name: auth_permission auth_permission_content_type_id_codename_01ab375a_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_codename_01ab375a_uniq UNIQUE (content_type_id, codename);


--
-- Name: auth_permission auth_permission_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_pkey PRIMARY KEY (id);


--
-- Name: authtoken_token authtoken_token_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.authtoken_token
    ADD CONSTRAINT authtoken_token_pkey PRIMARY KEY (key);


--
-- Name: authtoken_token authtoken_token_user_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.authtoken_token
    ADD CONSTRAINT authtoken_token_user_id_key UNIQUE (user_id);


--
-- Name: captcha_captchastore captcha_captchastore_hashkey_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.captcha_captchastore
    ADD CONSTRAINT captcha_captchastore_hashkey_key UNIQUE (hashkey);


--
-- Name: captcha_captchastore captcha_captchastore_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.captcha_captchastore
    ADD CONSTRAINT captcha_captchastore_pkey PRIMARY KEY (id);


--
-- Name: core_article_hash_tags core_article_hash_tags_article_id_hashtag_id_02d9cfaf_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_article_hash_tags
    ADD CONSTRAINT core_article_hash_tags_article_id_hashtag_id_02d9cfaf_uniq UNIQUE (article_id, hashtag_id);


--
-- Name: core_article_hash_tags core_article_hash_tags_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_article_hash_tags
    ADD CONSTRAINT core_article_hash_tags_pkey PRIMARY KEY (id);


--
-- Name: core_article core_article_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_article
    ADD CONSTRAINT core_article_pkey PRIMARY KEY (id);


--
-- Name: core_articlemedia core_articlemedia_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_articlemedia
    ADD CONSTRAINT core_articlemedia_pkey PRIMARY KEY (id);


--
-- Name: core_articlerating core_articlerating_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_articlerating
    ADD CONSTRAINT core_articlerating_pkey PRIMARY KEY (id);


--
-- Name: core_articlelike core_artilclelike_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_articlelike
    ADD CONSTRAINT core_artilclelike_pkey PRIMARY KEY (id);


--
-- Name: core_baseuserprofile_groups core_baseuserprofile_gro_baseuserprofile_id_group_e48e3740_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_baseuserprofile_groups
    ADD CONSTRAINT core_baseuserprofile_gro_baseuserprofile_id_group_e48e3740_uniq UNIQUE (baseuserprofile_id, group_id);


--
-- Name: core_baseuserprofile_groups core_baseuserprofile_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_baseuserprofile_groups
    ADD CONSTRAINT core_baseuserprofile_groups_pkey PRIMARY KEY (id);


--
-- Name: core_baseuserprofile_passion core_baseuserprofile_pas_baseuserprofile_id_hasht_5878cefc_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_baseuserprofile_passion
    ADD CONSTRAINT core_baseuserprofile_pas_baseuserprofile_id_hasht_5878cefc_uniq UNIQUE (baseuserprofile_id, hashtag_id);


--
-- Name: core_baseuserprofile_passion core_baseuserprofile_passion_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_baseuserprofile_passion
    ADD CONSTRAINT core_baseuserprofile_passion_pkey PRIMARY KEY (id);


--
-- Name: core_baseuserprofile core_baseuserprofile_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_baseuserprofile
    ADD CONSTRAINT core_baseuserprofile_pkey PRIMARY KEY (id);


--
-- Name: core_baseuserprofile_user_permissions core_baseuserprofile_use_baseuserprofile_id_permi_248e3df6_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_baseuserprofile_user_permissions
    ADD CONSTRAINT core_baseuserprofile_use_baseuserprofile_id_permi_248e3df6_uniq UNIQUE (baseuserprofile_id, permission_id);


--
-- Name: core_baseuserprofile_user_permissions core_baseuserprofile_user_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_baseuserprofile_user_permissions
    ADD CONSTRAINT core_baseuserprofile_user_permissions_pkey PRIMARY KEY (id);


--
-- Name: core_baseuserprofile core_baseuserprofile_username_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_baseuserprofile
    ADD CONSTRAINT core_baseuserprofile_username_key UNIQUE (username);


--
-- Name: core_bookmarkarticle core_bookmarkarticle_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_bookmarkarticle
    ADD CONSTRAINT core_bookmarkarticle_pkey PRIMARY KEY (id);


--
-- Name: core_category core_category_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_category
    ADD CONSTRAINT core_category_pkey PRIMARY KEY (id);


--
-- Name: core_categoryassociation core_categoryassociation_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_categoryassociation
    ADD CONSTRAINT core_categoryassociation_pkey PRIMARY KEY (id);


--
-- Name: core_categorydefaultimage core_categorydefaultimage_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_categorydefaultimage
    ADD CONSTRAINT core_categorydefaultimage_pkey PRIMARY KEY (id);


--
-- Name: core_comment core_comment_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_comment
    ADD CONSTRAINT core_comment_pkey PRIMARY KEY (id);


--
-- Name: core_dailydigest_articles core_dailydigest_article_dailydigest_id_article_i_75726f66_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_dailydigest_articles
    ADD CONSTRAINT core_dailydigest_article_dailydigest_id_article_i_75726f66_uniq UNIQUE (dailydigest_id, article_id);


--
-- Name: core_dailydigest_articles core_dailydigest_articles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_dailydigest_articles
    ADD CONSTRAINT core_dailydigest_articles_pkey PRIMARY KEY (id);


--
-- Name: core_dailydigest core_dailydigest_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_dailydigest
    ADD CONSTRAINT core_dailydigest_pkey PRIMARY KEY (id);


--
-- Name: core_devices core_devices_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_devices
    ADD CONSTRAINT core_devices_pkey PRIMARY KEY (id);


--
-- Name: core_domain core_domain_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_domain
    ADD CONSTRAINT core_domain_pkey PRIMARY KEY (id);


--
-- Name: core_draftmedia core_draftmedia_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_draftmedia
    ADD CONSTRAINT core_draftmedia_pkey PRIMARY KEY (id);


--
-- Name: core_hashtag core_hashtag_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_hashtag
    ADD CONSTRAINT core_hashtag_pkey PRIMARY KEY (id);


--
-- Name: core_menu core_menu_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_menu
    ADD CONSTRAINT core_menu_pkey PRIMARY KEY (id);


--
-- Name: core_menu_submenu core_menu_submenu_menu_id_submenu_id_551b35ce_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_menu_submenu
    ADD CONSTRAINT core_menu_submenu_menu_id_submenu_id_551b35ce_uniq UNIQUE (menu_id, submenu_id);


--
-- Name: core_menu_submenu core_menu_submenu_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_menu_submenu
    ADD CONSTRAINT core_menu_submenu_pkey PRIMARY KEY (id);


--
-- Name: core_notification core_notification_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_notification
    ADD CONSTRAINT core_notification_pkey PRIMARY KEY (id);


--
-- Name: core_relatedarticle core_relatedarticle_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_relatedarticle
    ADD CONSTRAINT core_relatedarticle_pkey PRIMARY KEY (id);


--
-- Name: core_scouteditem core_scouteditem_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_scouteditem
    ADD CONSTRAINT core_scouteditem_pkey PRIMARY KEY (id);


--
-- Name: core_scoutfrontier core_scoutfrontier_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_scoutfrontier
    ADD CONSTRAINT core_scoutfrontier_pkey PRIMARY KEY (id);


--
-- Name: core_socialaccount core_socialaccount_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_socialaccount
    ADD CONSTRAINT core_socialaccount_pkey PRIMARY KEY (id);


--
-- Name: core_source core_source_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_source
    ADD CONSTRAINT core_source_pkey PRIMARY KEY (id);


--
-- Name: core_submenu_hash_tags core_submenu_hash_tags_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_submenu_hash_tags
    ADD CONSTRAINT core_submenu_hash_tags_pkey PRIMARY KEY (id);


--
-- Name: core_submenu_hash_tags core_submenu_hash_tags_submenu_id_hashtag_id_8e4e784e_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_submenu_hash_tags
    ADD CONSTRAINT core_submenu_hash_tags_submenu_id_hashtag_id_8e4e784e_uniq UNIQUE (submenu_id, hashtag_id);


--
-- Name: core_submenu core_submenu_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_submenu
    ADD CONSTRAINT core_submenu_pkey PRIMARY KEY (id);


--
-- Name: core_trendingarticle_articles core_trendingarticle_art_trendingarticle_id_artic_630a4769_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_trendingarticle_articles
    ADD CONSTRAINT core_trendingarticle_art_trendingarticle_id_artic_630a4769_uniq UNIQUE (trendingarticle_id, article_id);


--
-- Name: core_trendingarticle_articles core_trendingarticle_articles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_trendingarticle_articles
    ADD CONSTRAINT core_trendingarticle_articles_pkey PRIMARY KEY (id);


--
-- Name: core_trendingarticle core_trendingarticle_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_trendingarticle
    ADD CONSTRAINT core_trendingarticle_pkey PRIMARY KEY (id);


--
-- Name: core_trendinghashtag core_trendinghashtag_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_trendinghashtag
    ADD CONSTRAINT core_trendinghashtag_pkey PRIMARY KEY (id);


--
-- Name: django_admin_log django_admin_log_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_pkey PRIMARY KEY (id);


--
-- Name: django_content_type django_content_type_app_label_model_76bd3d3b_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_app_label_model_76bd3d3b_uniq UNIQUE (app_label, model);


--
-- Name: django_content_type django_content_type_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_pkey PRIMARY KEY (id);


--
-- Name: django_migrations django_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_migrations
    ADD CONSTRAINT django_migrations_pkey PRIMARY KEY (id);


--
-- Name: django_session django_session_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_session
    ADD CONSTRAINT django_session_pkey PRIMARY KEY (session_key);


--
-- Name: advertising_adgroup_campaign_id_efd6fa23; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX advertising_adgroup_campaign_id_efd6fa23 ON public.advertising_adgroup USING btree (campaign_id);


--
-- Name: advertising_adgroup_category_adgroup_id_308d8916; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX advertising_adgroup_category_adgroup_id_308d8916 ON public.advertising_adgroup_category USING btree (adgroup_id);


--
-- Name: advertising_adgroup_category_category_id_a26fe99b; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX advertising_adgroup_category_category_id_a26fe99b ON public.advertising_adgroup_category USING btree (category_id);


--
-- Name: advertising_advertisement_ad_type_id_64de1c64; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX advertising_advertisement_ad_type_id_64de1c64 ON public.advertising_advertisement USING btree (ad_type_id);


--
-- Name: advertising_advertisement_adgroup_id_f1f9da2e; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX advertising_advertisement_adgroup_id_f1f9da2e ON public.advertising_advertisement USING btree (adgroup_id);


--
-- Name: advertising_campaign_domain_id_1f086d49; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX advertising_campaign_domain_id_1f086d49 ON public.advertising_campaign USING btree (domain_id);


--
-- Name: auth_group_name_a6ea08ec_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_group_name_a6ea08ec_like ON public.auth_group USING btree (name varchar_pattern_ops);


--
-- Name: auth_group_permissions_group_id_b120cbf9; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_group_permissions_group_id_b120cbf9 ON public.auth_group_permissions USING btree (group_id);


--
-- Name: auth_group_permissions_permission_id_84c5c92e; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_group_permissions_permission_id_84c5c92e ON public.auth_group_permissions USING btree (permission_id);


--
-- Name: auth_permission_content_type_id_2f476e4b; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_permission_content_type_id_2f476e4b ON public.auth_permission USING btree (content_type_id);


--
-- Name: authtoken_token_key_10f0b77e_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX authtoken_token_key_10f0b77e_like ON public.authtoken_token USING btree (key varchar_pattern_ops);


--
-- Name: captcha_captchastore_hashkey_cbe8d15a_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX captcha_captchastore_hashkey_cbe8d15a_like ON public.captcha_captchastore USING btree (hashkey varchar_pattern_ops);


--
-- Name: core_article_author_id_2a735552; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_article_author_id_2a735552 ON public.core_article USING btree (author_id);


--
-- Name: core_article_category_id_6a048cbb; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_article_category_id_6a048cbb ON public.core_article USING btree (category_id);


--
-- Name: core_article_domain_id_c533d882; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_article_domain_id_c533d882 ON public.core_article USING btree (domain_id);


--
-- Name: core_article_edited_by_id_7163811d; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_article_edited_by_id_7163811d ON public.core_article USING btree (edited_by_id);


--
-- Name: core_article_hash_tags_article_id_b88c21b0; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_article_hash_tags_article_id_b88c21b0 ON public.core_article_hash_tags USING btree (article_id);


--
-- Name: core_article_hash_tags_hashtag_id_433871bd; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_article_hash_tags_hashtag_id_433871bd ON public.core_article_hash_tags USING btree (hashtag_id);


--
-- Name: core_article_slug_7d9993a0; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_article_slug_7d9993a0 ON public.core_article USING btree (slug);


--
-- Name: core_article_slug_7d9993a0_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_article_slug_7d9993a0_like ON public.core_article USING btree (slug varchar_pattern_ops);


--
-- Name: core_article_source_id_674c71a5; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_article_source_id_674c71a5 ON public.core_article USING btree (source_id);


--
-- Name: core_articlemedia_article_id_ea848b0f; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_articlemedia_article_id_ea848b0f ON public.core_articlemedia USING btree (article_id);


--
-- Name: core_articlerating_article_id_8bd3d1ab; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_articlerating_article_id_8bd3d1ab ON public.core_articlerating USING btree (article_id);


--
-- Name: core_artilclelike_article_id_d6775764; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_artilclelike_article_id_d6775764 ON public.core_articlelike USING btree (article_id);


--
-- Name: core_artilclelike_user_id_af3b3ccf; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_artilclelike_user_id_af3b3ccf ON public.core_articlelike USING btree (user_id);


--
-- Name: core_baseuserprofile_domain_id_6921615b; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_baseuserprofile_domain_id_6921615b ON public.core_baseuserprofile USING btree (domain_id);


--
-- Name: core_baseuserprofile_groups_baseuserprofile_id_68c24add; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_baseuserprofile_groups_baseuserprofile_id_68c24add ON public.core_baseuserprofile_groups USING btree (baseuserprofile_id);


--
-- Name: core_baseuserprofile_groups_group_id_e1a287cf; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_baseuserprofile_groups_group_id_e1a287cf ON public.core_baseuserprofile_groups USING btree (group_id);


--
-- Name: core_baseuserprofile_passion_baseuserprofile_id_c0f81d64; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_baseuserprofile_passion_baseuserprofile_id_c0f81d64 ON public.core_baseuserprofile_passion USING btree (baseuserprofile_id);


--
-- Name: core_baseuserprofile_passion_hashtag_id_e45c5980; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_baseuserprofile_passion_hashtag_id_e45c5980 ON public.core_baseuserprofile_passion USING btree (hashtag_id);


--
-- Name: core_baseuserprofile_user__baseuserprofile_id_c2de2330; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_baseuserprofile_user__baseuserprofile_id_c2de2330 ON public.core_baseuserprofile_user_permissions USING btree (baseuserprofile_id);


--
-- Name: core_baseuserprofile_user_permissions_permission_id_653ab7cf; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_baseuserprofile_user_permissions_permission_id_653ab7cf ON public.core_baseuserprofile_user_permissions USING btree (permission_id);


--
-- Name: core_baseuserprofile_username_70779676_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_baseuserprofile_username_70779676_like ON public.core_baseuserprofile USING btree (username varchar_pattern_ops);


--
-- Name: core_bookmarkarticle_article_id_738fb79a; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_bookmarkarticle_article_id_738fb79a ON public.core_bookmarkarticle USING btree (article_id);


--
-- Name: core_bookmarkarticle_user_id_86a067ca; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_bookmarkarticle_user_id_86a067ca ON public.core_bookmarkarticle USING btree (user_id);


--
-- Name: core_categoryassociation_child_cat_id_a91a2a4e; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_categoryassociation_child_cat_id_a91a2a4e ON public.core_categoryassociation USING btree (child_cat_id);


--
-- Name: core_categoryassociation_parent_cat_id_85a35750; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_categoryassociation_parent_cat_id_85a35750 ON public.core_categoryassociation USING btree (parent_cat_id);


--
-- Name: core_categorydefaultimage_category_id_1ba47a32; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_categorydefaultimage_category_id_1ba47a32 ON public.core_categorydefaultimage USING btree (category_id);


--
-- Name: core_comment_article_id_11dbd226; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_comment_article_id_11dbd226 ON public.core_comment USING btree (article_id);


--
-- Name: core_comment_reply_id_a9c85a57; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_comment_reply_id_a9c85a57 ON public.core_comment USING btree (reply_id);


--
-- Name: core_comment_user_id_a9a9430c; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_comment_user_id_a9a9430c ON public.core_comment USING btree (user_id);


--
-- Name: core_dailydigest_articles_article_id_b1dca094; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_dailydigest_articles_article_id_b1dca094 ON public.core_dailydigest_articles USING btree (article_id);


--
-- Name: core_dailydigest_articles_dailydigest_id_dd4d469e; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_dailydigest_articles_dailydigest_id_dd4d469e ON public.core_dailydigest_articles USING btree (dailydigest_id);


--
-- Name: core_dailydigest_device_id_db994240; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_dailydigest_device_id_db994240 ON public.core_dailydigest USING btree (device_id);


--
-- Name: core_dailydigest_domain_id_a2597fbd; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_dailydigest_domain_id_a2597fbd ON public.core_dailydigest USING btree (domain_id);


--
-- Name: core_devices_user_id_0ed77991; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_devices_user_id_0ed77991 ON public.core_devices USING btree (user_id);


--
-- Name: core_menu_domain_id_26d1ace8; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_menu_domain_id_26d1ace8 ON public.core_menu USING btree (domain_id);


--
-- Name: core_menu_name_id_606023c6; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_menu_name_id_606023c6 ON public.core_menu USING btree (name_id);


--
-- Name: core_menu_submenu_menu_id_35e87fbc; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_menu_submenu_menu_id_35e87fbc ON public.core_menu_submenu USING btree (menu_id);


--
-- Name: core_menu_submenu_submenu_id_b233956b; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_menu_submenu_submenu_id_b233956b ON public.core_menu_submenu USING btree (submenu_id);


--
-- Name: core_notification_device_id_215532d3; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_notification_device_id_215532d3 ON public.core_notification USING btree (device_id);


--
-- Name: core_relatedarticle_related_id_b7684c22; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_relatedarticle_related_id_b7684c22 ON public.core_relatedarticle USING btree (related_id);


--
-- Name: core_relatedarticle_source_id_0ed6a97d; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_relatedarticle_source_id_0ed6a97d ON public.core_relatedarticle USING btree (source_id);


--
-- Name: core_scouteditem_category_id_230cc525; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_scouteditem_category_id_230cc525 ON public.core_scouteditem USING btree (category_id);


--
-- Name: core_scoutfrontier_category_id_230829bc; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_scoutfrontier_category_id_230829bc ON public.core_scoutfrontier USING btree (category_id);


--
-- Name: core_socialaccount_user_id_4da0b336; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_socialaccount_user_id_4da0b336 ON public.core_socialaccount USING btree (user_id);


--
-- Name: core_submenu_hash_tags_hashtag_id_70e26b30; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_submenu_hash_tags_hashtag_id_70e26b30 ON public.core_submenu_hash_tags USING btree (hashtag_id);


--
-- Name: core_submenu_hash_tags_submenu_id_2ca70b39; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_submenu_hash_tags_submenu_id_2ca70b39 ON public.core_submenu_hash_tags USING btree (submenu_id);


--
-- Name: core_submenu_name_id_dccdbf47; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_submenu_name_id_dccdbf47 ON public.core_submenu USING btree (name_id);


--
-- Name: core_trendingarticle_articles_article_id_01a5ee74; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_trendingarticle_articles_article_id_01a5ee74 ON public.core_trendingarticle_articles USING btree (article_id);


--
-- Name: core_trendingarticle_articles_trendingarticle_id_5f702398; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_trendingarticle_articles_trendingarticle_id_5f702398 ON public.core_trendingarticle_articles USING btree (trendingarticle_id);


--
-- Name: core_trendingarticle_domain_id_1d409d96; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_trendingarticle_domain_id_1d409d96 ON public.core_trendingarticle USING btree (domain_id);


--
-- Name: django_admin_log_content_type_id_c4bce8eb; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX django_admin_log_content_type_id_c4bce8eb ON public.django_admin_log USING btree (content_type_id);


--
-- Name: django_admin_log_user_id_c564eba6; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX django_admin_log_user_id_c564eba6 ON public.django_admin_log USING btree (user_id);


--
-- Name: django_session_expire_date_a5c62663; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX django_session_expire_date_a5c62663 ON public.django_session USING btree (expire_date);


--
-- Name: django_session_session_key_c0390e0f_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX django_session_session_key_c0390e0f_like ON public.django_session USING btree (session_key varchar_pattern_ops);


--
-- Name: advertising_adgroup_category advertising_adgroup__adgroup_id_308d8916_fk_advertisi; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.advertising_adgroup_category
    ADD CONSTRAINT advertising_adgroup__adgroup_id_308d8916_fk_advertisi FOREIGN KEY (adgroup_id) REFERENCES public.advertising_adgroup(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: advertising_adgroup_category advertising_adgroup__category_id_a26fe99b_fk_core_cate; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.advertising_adgroup_category
    ADD CONSTRAINT advertising_adgroup__category_id_a26fe99b_fk_core_cate FOREIGN KEY (category_id) REFERENCES public.core_category(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: advertising_adgroup advertising_adgroup_campaign_id_efd6fa23_fk_advertisi; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.advertising_adgroup
    ADD CONSTRAINT advertising_adgroup_campaign_id_efd6fa23_fk_advertisi FOREIGN KEY (campaign_id) REFERENCES public.advertising_campaign(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: advertising_advertisement advertising_advertis_ad_type_id_64de1c64_fk_advertisi; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.advertising_advertisement
    ADD CONSTRAINT advertising_advertis_ad_type_id_64de1c64_fk_advertisi FOREIGN KEY (ad_type_id) REFERENCES public.advertising_adtype(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: advertising_advertisement advertising_advertis_adgroup_id_f1f9da2e_fk_advertisi; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.advertising_advertisement
    ADD CONSTRAINT advertising_advertis_adgroup_id_f1f9da2e_fk_advertisi FOREIGN KEY (adgroup_id) REFERENCES public.advertising_adgroup(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: advertising_campaign advertising_campaign_domain_id_1f086d49_fk_core_domain_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.advertising_campaign
    ADD CONSTRAINT advertising_campaign_domain_id_1f086d49_fk_core_domain_id FOREIGN KEY (domain_id) REFERENCES public.core_domain(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permissions auth_group_permissio_permission_id_84c5c92e_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissio_permission_id_84c5c92e_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permissions auth_group_permissions_group_id_b120cbf9_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_b120cbf9_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_permission auth_permission_content_type_id_2f476e4b_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_2f476e4b_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: authtoken_token authtoken_token_user_id_35299eff_fk_core_baseuserprofile_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.authtoken_token
    ADD CONSTRAINT authtoken_token_user_id_35299eff_fk_core_baseuserprofile_id FOREIGN KEY (user_id) REFERENCES public.core_baseuserprofile(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_article core_article_author_id_2a735552_fk_core_baseuserprofile_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_article
    ADD CONSTRAINT core_article_author_id_2a735552_fk_core_baseuserprofile_id FOREIGN KEY (author_id) REFERENCES public.core_baseuserprofile(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_article core_article_category_id_6a048cbb_fk_core_category_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_article
    ADD CONSTRAINT core_article_category_id_6a048cbb_fk_core_category_id FOREIGN KEY (category_id) REFERENCES public.core_category(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_article core_article_domain_id_c533d882_fk_core_domain_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_article
    ADD CONSTRAINT core_article_domain_id_c533d882_fk_core_domain_id FOREIGN KEY (domain_id) REFERENCES public.core_domain(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_article core_article_edited_by_id_7163811d_fk_core_baseuserprofile_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_article
    ADD CONSTRAINT core_article_edited_by_id_7163811d_fk_core_baseuserprofile_id FOREIGN KEY (edited_by_id) REFERENCES public.core_baseuserprofile(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_article_hash_tags core_article_hash_tags_article_id_b88c21b0_fk_core_article_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_article_hash_tags
    ADD CONSTRAINT core_article_hash_tags_article_id_b88c21b0_fk_core_article_id FOREIGN KEY (article_id) REFERENCES public.core_article(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_article_hash_tags core_article_hash_tags_hashtag_id_433871bd_fk_core_hashtag_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_article_hash_tags
    ADD CONSTRAINT core_article_hash_tags_hashtag_id_433871bd_fk_core_hashtag_id FOREIGN KEY (hashtag_id) REFERENCES public.core_hashtag(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_article core_article_source_id_674c71a5_fk_core_source_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_article
    ADD CONSTRAINT core_article_source_id_674c71a5_fk_core_source_id FOREIGN KEY (source_id) REFERENCES public.core_source(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_articlemedia core_articlemedia_article_id_ea848b0f_fk_core_article_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_articlemedia
    ADD CONSTRAINT core_articlemedia_article_id_ea848b0f_fk_core_article_id FOREIGN KEY (article_id) REFERENCES public.core_article(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_articlerating core_articlerating_article_id_8bd3d1ab_fk_core_article_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_articlerating
    ADD CONSTRAINT core_articlerating_article_id_8bd3d1ab_fk_core_article_id FOREIGN KEY (article_id) REFERENCES public.core_article(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_articlelike core_artilclelike_article_id_d6775764_fk_core_article_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_articlelike
    ADD CONSTRAINT core_artilclelike_article_id_d6775764_fk_core_article_id FOREIGN KEY (article_id) REFERENCES public.core_article(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_articlelike core_artilclelike_user_id_af3b3ccf_fk_core_baseuserprofile_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_articlelike
    ADD CONSTRAINT core_artilclelike_user_id_af3b3ccf_fk_core_baseuserprofile_id FOREIGN KEY (user_id) REFERENCES public.core_baseuserprofile(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_baseuserprofile_groups core_baseuserprofile_baseuserprofile_id_68c24add_fk_core_base; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_baseuserprofile_groups
    ADD CONSTRAINT core_baseuserprofile_baseuserprofile_id_68c24add_fk_core_base FOREIGN KEY (baseuserprofile_id) REFERENCES public.core_baseuserprofile(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_baseuserprofile_passion core_baseuserprofile_baseuserprofile_id_c0f81d64_fk_core_base; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_baseuserprofile_passion
    ADD CONSTRAINT core_baseuserprofile_baseuserprofile_id_c0f81d64_fk_core_base FOREIGN KEY (baseuserprofile_id) REFERENCES public.core_baseuserprofile(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_baseuserprofile_user_permissions core_baseuserprofile_baseuserprofile_id_c2de2330_fk_core_base; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_baseuserprofile_user_permissions
    ADD CONSTRAINT core_baseuserprofile_baseuserprofile_id_c2de2330_fk_core_base FOREIGN KEY (baseuserprofile_id) REFERENCES public.core_baseuserprofile(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_baseuserprofile core_baseuserprofile_domain_id_6921615b_fk_core_domain_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_baseuserprofile
    ADD CONSTRAINT core_baseuserprofile_domain_id_6921615b_fk_core_domain_id FOREIGN KEY (domain_id) REFERENCES public.core_domain(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_baseuserprofile_groups core_baseuserprofile_groups_group_id_e1a287cf_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_baseuserprofile_groups
    ADD CONSTRAINT core_baseuserprofile_groups_group_id_e1a287cf_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_baseuserprofile_passion core_baseuserprofile_hashtag_id_e45c5980_fk_core_hash; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_baseuserprofile_passion
    ADD CONSTRAINT core_baseuserprofile_hashtag_id_e45c5980_fk_core_hash FOREIGN KEY (hashtag_id) REFERENCES public.core_hashtag(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_baseuserprofile_user_permissions core_baseuserprofile_permission_id_653ab7cf_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_baseuserprofile_user_permissions
    ADD CONSTRAINT core_baseuserprofile_permission_id_653ab7cf_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_bookmarkarticle core_bookmarkarticle_article_id_738fb79a_fk_core_article_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_bookmarkarticle
    ADD CONSTRAINT core_bookmarkarticle_article_id_738fb79a_fk_core_article_id FOREIGN KEY (article_id) REFERENCES public.core_article(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_bookmarkarticle core_bookmarkarticle_user_id_86a067ca_fk_core_base; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_bookmarkarticle
    ADD CONSTRAINT core_bookmarkarticle_user_id_86a067ca_fk_core_base FOREIGN KEY (user_id) REFERENCES public.core_baseuserprofile(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_categoryassociation core_categoryassocia_child_cat_id_a91a2a4e_fk_core_cate; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_categoryassociation
    ADD CONSTRAINT core_categoryassocia_child_cat_id_a91a2a4e_fk_core_cate FOREIGN KEY (child_cat_id) REFERENCES public.core_category(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_categoryassociation core_categoryassocia_parent_cat_id_85a35750_fk_core_cate; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_categoryassociation
    ADD CONSTRAINT core_categoryassocia_parent_cat_id_85a35750_fk_core_cate FOREIGN KEY (parent_cat_id) REFERENCES public.core_category(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_categorydefaultimage core_categorydefault_category_id_1ba47a32_fk_core_cate; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_categorydefaultimage
    ADD CONSTRAINT core_categorydefault_category_id_1ba47a32_fk_core_cate FOREIGN KEY (category_id) REFERENCES public.core_category(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_comment core_comment_article_id_11dbd226_fk_core_article_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_comment
    ADD CONSTRAINT core_comment_article_id_11dbd226_fk_core_article_id FOREIGN KEY (article_id) REFERENCES public.core_article(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_comment core_comment_reply_id_a9c85a57_fk_core_comment_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_comment
    ADD CONSTRAINT core_comment_reply_id_a9c85a57_fk_core_comment_id FOREIGN KEY (reply_id) REFERENCES public.core_comment(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_comment core_comment_user_id_a9a9430c_fk_core_baseuserprofile_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_comment
    ADD CONSTRAINT core_comment_user_id_a9a9430c_fk_core_baseuserprofile_id FOREIGN KEY (user_id) REFERENCES public.core_baseuserprofile(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_dailydigest_articles core_dailydigest_art_article_id_b1dca094_fk_core_arti; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_dailydigest_articles
    ADD CONSTRAINT core_dailydigest_art_article_id_b1dca094_fk_core_arti FOREIGN KEY (article_id) REFERENCES public.core_article(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_dailydigest_articles core_dailydigest_art_dailydigest_id_dd4d469e_fk_core_dail; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_dailydigest_articles
    ADD CONSTRAINT core_dailydigest_art_dailydigest_id_dd4d469e_fk_core_dail FOREIGN KEY (dailydigest_id) REFERENCES public.core_dailydigest(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_dailydigest core_dailydigest_device_id_db994240_fk_core_devices_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_dailydigest
    ADD CONSTRAINT core_dailydigest_device_id_db994240_fk_core_devices_id FOREIGN KEY (device_id) REFERENCES public.core_devices(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_dailydigest core_dailydigest_domain_id_a2597fbd_fk_core_domain_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_dailydigest
    ADD CONSTRAINT core_dailydigest_domain_id_a2597fbd_fk_core_domain_id FOREIGN KEY (domain_id) REFERENCES public.core_domain(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_devices core_devices_user_id_0ed77991_fk_core_baseuserprofile_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_devices
    ADD CONSTRAINT core_devices_user_id_0ed77991_fk_core_baseuserprofile_id FOREIGN KEY (user_id) REFERENCES public.core_baseuserprofile(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_menu core_menu_domain_id_26d1ace8_fk_core_domain_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_menu
    ADD CONSTRAINT core_menu_domain_id_26d1ace8_fk_core_domain_id FOREIGN KEY (domain_id) REFERENCES public.core_domain(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_menu core_menu_name_id_606023c6_fk_core_category_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_menu
    ADD CONSTRAINT core_menu_name_id_606023c6_fk_core_category_id FOREIGN KEY (name_id) REFERENCES public.core_category(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_menu_submenu core_menu_submenu_menu_id_35e87fbc_fk_core_menu_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_menu_submenu
    ADD CONSTRAINT core_menu_submenu_menu_id_35e87fbc_fk_core_menu_id FOREIGN KEY (menu_id) REFERENCES public.core_menu(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_menu_submenu core_menu_submenu_submenu_id_b233956b_fk_core_submenu_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_menu_submenu
    ADD CONSTRAINT core_menu_submenu_submenu_id_b233956b_fk_core_submenu_id FOREIGN KEY (submenu_id) REFERENCES public.core_submenu(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_notification core_notification_device_id_215532d3_fk_core_devices_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_notification
    ADD CONSTRAINT core_notification_device_id_215532d3_fk_core_devices_id FOREIGN KEY (device_id) REFERENCES public.core_devices(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_relatedarticle core_relatedarticle_related_id_b7684c22_fk_core_article_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_relatedarticle
    ADD CONSTRAINT core_relatedarticle_related_id_b7684c22_fk_core_article_id FOREIGN KEY (related_id) REFERENCES public.core_article(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_relatedarticle core_relatedarticle_source_id_0ed6a97d_fk_core_article_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_relatedarticle
    ADD CONSTRAINT core_relatedarticle_source_id_0ed6a97d_fk_core_article_id FOREIGN KEY (source_id) REFERENCES public.core_article(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_scouteditem core_scouteditem_category_id_230cc525_fk_core_category_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_scouteditem
    ADD CONSTRAINT core_scouteditem_category_id_230cc525_fk_core_category_id FOREIGN KEY (category_id) REFERENCES public.core_category(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_scoutfrontier core_scoutfrontier_category_id_230829bc_fk_core_category_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_scoutfrontier
    ADD CONSTRAINT core_scoutfrontier_category_id_230829bc_fk_core_category_id FOREIGN KEY (category_id) REFERENCES public.core_category(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_socialaccount core_socialaccount_user_id_4da0b336_fk_core_baseuserprofile_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_socialaccount
    ADD CONSTRAINT core_socialaccount_user_id_4da0b336_fk_core_baseuserprofile_id FOREIGN KEY (user_id) REFERENCES public.core_baseuserprofile(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_submenu_hash_tags core_submenu_hash_tags_hashtag_id_70e26b30_fk_core_hashtag_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_submenu_hash_tags
    ADD CONSTRAINT core_submenu_hash_tags_hashtag_id_70e26b30_fk_core_hashtag_id FOREIGN KEY (hashtag_id) REFERENCES public.core_hashtag(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_submenu_hash_tags core_submenu_hash_tags_submenu_id_2ca70b39_fk_core_submenu_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_submenu_hash_tags
    ADD CONSTRAINT core_submenu_hash_tags_submenu_id_2ca70b39_fk_core_submenu_id FOREIGN KEY (submenu_id) REFERENCES public.core_submenu(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_submenu core_submenu_name_id_dccdbf47_fk_core_category_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_submenu
    ADD CONSTRAINT core_submenu_name_id_dccdbf47_fk_core_category_id FOREIGN KEY (name_id) REFERENCES public.core_category(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_trendingarticle_articles core_trendingarticle_article_id_01a5ee74_fk_core_arti; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_trendingarticle_articles
    ADD CONSTRAINT core_trendingarticle_article_id_01a5ee74_fk_core_arti FOREIGN KEY (article_id) REFERENCES public.core_article(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_trendingarticle core_trendingarticle_domain_id_1d409d96_fk_core_domain_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_trendingarticle
    ADD CONSTRAINT core_trendingarticle_domain_id_1d409d96_fk_core_domain_id FOREIGN KEY (domain_id) REFERENCES public.core_domain(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_trendingarticle_articles core_trendingarticle_trendingarticle_id_5f702398_fk_core_tren; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_trendingarticle_articles
    ADD CONSTRAINT core_trendingarticle_trendingarticle_id_5f702398_fk_core_tren FOREIGN KEY (trendingarticle_id) REFERENCES public.core_trendingarticle(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log django_admin_log_content_type_id_c4bce8eb_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_content_type_id_c4bce8eb_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log django_admin_log_user_id_c564eba6_fk_core_baseuserprofile_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_user_id_c564eba6_fk_core_baseuserprofile_id FOREIGN KEY (user_id) REFERENCES public.core_baseuserprofile(id) DEFERRABLE INITIALLY DEFERRED;


--
-- PostgreSQL database dump complete
--

